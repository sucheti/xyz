(function () {
    'use strict';

    angular.module('gsesp.disassembly-code', [
        'ui.bootstrap'

    ]);
})();

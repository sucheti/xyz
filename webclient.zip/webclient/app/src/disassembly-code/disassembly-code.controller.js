(function () {
    'use strict';
    angular.module('gsesp.disassembly-code')
            .controller('DisassemblyCodeController', DisassemblyCodeController);
    DisassemblyCodeController.$inject = ['rejectCodeService', '$uibModal', '$scope', 'requestsService', 'growlService', 'messages', 'maxNeedByDate', '$stateParams', 'requestTypeConstants',
        'requestStatus', 'FileService', 'authService', 'masterService', 'masterTypeConstants', 'requestStatusName', '$state', 'searchStateService', 'templateName'];
    function DisassemblyCodeController(rejectCodeService, $uibModal, $scope, requestsService, growlService, messages, maxNeedByDate, $stateParams, requestTypeConstants,
            requestStatus, FileService, authService, masterService, masterTypeConstants, requestStatusName, $state, searchStateService, templateName) {

        var vm = this;
        vm.request = {};
        vm.requesterInGet = {};
        vm.isDownload = false;
        vm.isSave = false;
        vm.isSaveAndSubmit = false;
        vm.isShowSave = true;
        vm.datePickerOpened = false;
        vm.isFileName = false;
        vm.isSubmitted = false;
        vm.isResponseComments = true;
        vm.isFileDownload = true;
        vm.isAllowedManager = false;
        vm.iterate = false;
        vm.isDisassemblyCode = true;
        vm.isRequestComments = false;
        vm.isFileUpload = true;
        vm.isDeleteFile = false;
        vm.isRequestorPhoneNumber = false;
        vm.isManagerPhoneNumber = false;
        vm.format = 'dd-MMM-yyyy';
        vm.isReadOnly = false;
        vm.isActive = 1;
        vm.isDirtyAlert = true;
	vm.reportName = templateName.DISASSEMBLY_CODE_REPORT_NAME;
        initialize();
        vm.newRequest = newRequest;
        vm.save = save;
        vm.saveAndSubmit = saveAndSubmit;
        vm.complete = complete;
        vm.reject = reject;
        vm.update = update;
        vm.create = create;
        vm.download = download;
        vm.deleteFile = deleteFile;
        vm.get = get;
        vm.uploadDoc = uploadDoc;
        vm.resetDoctype = resetDoctype;
        vm.updateSearchList = updateSearchList;
        vm.hasChanges = hasChanges;


        function intializeDateOptions() {

            vm.dateOptions = {
                formatYear: 'yy',
                minDate: new Date(),
                format: 'dd-MMM-yyyy',
                initDate: new Date()

            };
            
            vm.dateOptions.minDate.setDate(vm.dateOptions.minDate.getDate() + maxNeedByDate.REQUEST_NEED_BYDATE);
            vm.dateOptions.initDate = angular.copy(vm.dateOptions.minDate);
        }

        function initialize() {
            vm.request.docTypes = [];
            vm.request.disassemblyCodeVariants = [];
            vm.loggedInUser = {};
            vm.request.status = {};
	    vm.runReport = runReport;
            vm.temp = [];
            vm.isDirtyAlert = true;
            getLoggedInUser();
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.AIRPLANE_MODEL_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        angular.forEach(response, function (value, key) {
                            if (!vm.iterate) {
                                if (value.airplaneModel === masterTypeConstants.DISASSEMBLY_CODE_MODEL_CONSTANT) {
                                    vm.modelOptions = [value];
                                    vm.request.airplaneModels = vm.modelOptions;
                                    vm.iterate = true;
                                }
                            }
                        });
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.DOC_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.doctypeOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.ATA,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.ataChapter = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.DISASSEMBLY_PREFIX,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.prefix = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.DC_ACTION,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.dcActions = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.VC_ACTION,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.vcActions = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });

            rejectCodeService.get(
                    {
                        requestTypeName: requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.rejectionCodeOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.message, 'danger');
                    });

            vm.isResponseComments = true;
            intializeDateOptions();
            if (angular.isDefined($stateParams.requestId) && $stateParams.requestId !== '') {
                get($stateParams.requestId);
            } else {
                vm.request.status.statusName = requestStatusName.DRAFT;

            }


        }
	
	function runReport(){			
            var uibModalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'src/reports/report-modal.html',
                controller: 'ReportModalController',
                controllerAs: 'vm',
                size: 'reportmodal',
                backdrop: 'static',
                keyboard: true,
                resolve: {
                    parent: function () {
                        return vm;
                    }
                }
            });                
        }

        $scope.$on('isFormDirty', function (event) {
            hasChanges();
        });

        function newRequest() {
            vm.form.$submitted = false;
            if (hasChanges()) {
                swal({
                    title: messages.common.dirtyAlertTitleMessage,
                    text: messages.common.nonRecoverTextMessage,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Create a New Request",
                    closeOnConfirm: false
                }, function () {
                    swal(messages.common.createNewRequestSuccessTitleMessage, messages.common.createNewRequestSuccessTextMessage, "success");
                    newRequestConfirm();
                });
            } else {
                newRequestConfirm();
            }
        }

        function newRequestConfirm() {

            vm.form.$submitted = false;
            vm.isSubmitted = false;
            //vm.isResponseComments = true;

            vm.isFileName = false;
            vm.isDownload = false;
            vm.isFileUpload = true;
            vm.request.requestComments = "";
            vm.request = {};
            vm.request.requester = {};
            vm.isRequestStatus = false;
            vm.request.status = {};
            getLoggedInUser();
            searchStateService.isNewRequest = true;
            vm.request.status.statusName = requestStatusName.DRAFT;
            vm.request.status.statusId = requestStatus.DRAFT;
            vm.request.disassemblyCodeVariants = null;
            vm.request.disassemblyCodeVariants = [];
            populateModel();

            intializeDateOptions();
            vm.form.$setPristine();
            vm.form.$setUntouched();
            $state.go('request.disassembly-code', {requestId: vm.request.requestId});
        }



        function get(requestId) {
            vm.isSubmitted = true;
            vm.datePickerOpened = false;
            vm.isFileUpload = false;
            searchStateService.state = {};
            return requestsService.get(vm.filters,
                    {
                        requestTypeName: requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME,
                        requestId: requestId
                    },
                    function (response) {
                        vm.request = response;
                        angular.copy(vm.request, vm.requesterInGet);
                        if (angular.isDefined(vm.request.fileName) && vm.request.fileName !== null) {
                            vm.isFileName = true;
                        }

                        vm.isRequestorPhoneNumber = false;
                        enableOrDisable(vm.request);
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
        }

        function save() {
            vm.form.$submitted = true;
            if (searchStateService.filters.isDraft) {
                searchStateService.state = {};
            }
            if (angular.isDefined(vm.request.requestId)) {
                update();
            } else {
                create();
            }
        }

        function saveAndSubmit() {
            vm.form.$submitted = true;
            vm.request.submit = true;
            if (searchStateService.filters.isOpen) {
                searchStateService.state = {};
            }
            if (angular.isDefined(vm.request.requestId)) {
                update();
            } else {
                create();
            }
        }

        function create() {
            if (validateRequest(vm.request)) {
                if (validateDisassemblyCodeVariantCheck(vm.request)) {
                    requestsService.save({
                        requestTypeName: requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME
                    }, vm.request,
                            function (response) {
                                vm.request = response;
                                if (vm.request.submit) {
                                    growlService.growl(messages.disassemblyCode.disassemblyCodeSaveAndSubmitSuccessful, 'success');

                                } else {
                                    growlService.growl(messages.disassemblyCode.disassemblyCodeSaveSuccessful, 'success');
                                }
                                vm.isDirtyAlert = false;
                                enableOrDisable(response);
                                vm.form.$setPristine();
                                vm.form.$setUntouched();
                                $state.go('request.disassembly-code', {requestId: vm.request.requestId});
                            },
                            function (error) {
                                growlService.growl(error.data.message, 'danger');
                            });
                }
            } else {
                growlService.growl(messages.common.enterMandatoryFields, 'danger');
            }
        }

        function update() {
            if (validateRequest(vm.request)) {
                if (validateDisassemblyCodeVariantCheck(vm.request)) {
                    requestsService.update({
                        requestTypeName: requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME,
                        requestId: vm.request.requestId
                    }, vm.request,
                            function (response) {
                                vm.request = response;
                                vm.isRequestStatus = true;
                                if (vm.request.submit)
                                {
                                    updateSearchList();
                                    growlService.growl(messages.disassemblyCode.disassemblyCodeSaveAndSubmitSuccessful, 'success');
                                } else
                                    growlService.growl(messages.disassemblyCode.disassemblyCodeSaveSuccessful, 'success');
                                vm.isDirtyAlert = false;
                                enableOrDisable(response);
                                vm.form.$setPristine();
                                vm.form.$setUntouched();
                            },
                            function (error) {
                                growlService.growl(error.data.message, 'danger');
                            });
                }
            } else {
                growlService.growl(messages.common.enterMandatoryFields, 'danger');
            }
        }

        function complete() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {
                swal({
                    title: messages.common.completeAlertMessage1 + vm.request.requestId + messages.common.completeAlertMessage2,
                    type: "warning",
                    confirmButtonColor: "#3085d6",
                    confirmButtonText: "COMPLETE",
                    showCancelButton: true,
                    closeOnConfirm: true
                }, function () {
                    newCompleteConfirm();
                });
            } else {
                growlService.growl(messages.common.responseComments, 'danger');
            }
        }

        function newCompleteConfirm() {

            vm.request.requester = vm.requesterInGet.requester;
            return requestsService.complete({
                requestTypeName: requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME,
                requestId: vm.request.requestId
            }, vm.request,
                    function (response) {
                        vm.request = response;
                        growlService.growl(messages.disassemblyCode.disassemblyCodeCompleteRequestSuccessful, 'success');
                        vm.isSubmitted = true;
                        vm.form.$setPristine();
                        vm.form.$setUntouched();
                        updateSearchList();
                        enableOrDisable(response);
                        return response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
        }

        function reject() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {
                var uibModalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'src/requests/reject-code-modal.html',
                    controller: 'RejectCodeController',
                    controllerAs: 'vm',
                    size: 'rejectmodal',
                    backdrop: 'static',
                    keyboard: true,
                    resolve: {
                        parent: function () {
                            return vm;
                        }
                    }
                });
                uibModalInstance.result.then(function (selectedItem) {
                    vm.request.rejectionCodeVO = selectedItem;
                    newRejectConfirm();
                }, function () {
                    // modal dismissed
                });
            } else {
                if (vm.isRejectCode) {
                    growlService.growl(messages.common.rejectCode, 'danger');
                } else {
                    growlService.growl(messages.common.responseComments, 'danger');
                }
            }
        }

        function newRejectConfirm() {
            if (validateReject(vm.request)) {

                vm.request.requester = vm.requesterInGet.requester;
                return requestsService.reject({
                    requestTypeName: requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME,
                    requestId: vm.request.requestId
                }, vm.request,
                        function (response) {
                            vm.request = response;

                            growlService.growl(messages.disassemblyCode.disassemblyCodeRejectRequestSuccessful, 'success');
                            vm.isSubmitted = true;
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                            updateSearchList();
                            enableOrDisable(response);
                            return response;
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
            } else {
                if (vm.isRejectCode) {
                    growlService.growl(messages.common.rejectCode, 'danger');
                } else {
                    growlService.growl(messages.common.responseComments, 'danger');
                }
            }
        }


        function enableOrDisable(requestVO) {

            angular.forEach(vm.loggedInUser.managerItemVOs, function (value, key) {
                var isSearching = true;
                if (isSearching) {
                    if (value.managerItemTypeName === requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME) {
                        vm.isRequestComments = true;
                        vm.isAllowedManager = true;
                        switch (requestVO.status.statusId) {
                            case requestStatus.OPEN:
                                vm.isReadOnly = true;
                                vm.isShowNew = false;
                                vm.isShowSave = false;
                                vm.isShowComplete = true;
                                vm.isRequestStatus = true;
                                vm.isRejectedRequest = false;
                                vm.isResponseComments = false;

                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = false;
                                vm.isAllowedManagerResponseComment = false;
                                break;
                            case requestStatus.COMPLETE:
                                vm.isReadOnly = true;
                                vm.isResponseComments = true;
                                vm.isShowNew = true;
                                vm.isShowSave = false;
                                vm.isShowComplete = false;
                                vm.isFileUpload = true;
                                vm.isRejectedRequest = false;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = true;
                                vm.isRequestStatus = true;

                                break;
                            case  requestStatus.REJECT:
                                vm.isReadOnly = true;
                                vm.isResponseComments = true;
                                vm.isShowNew = true;
                                vm.isShowSave = false;
                                vm.isShowComplete = false;
                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = true;
                                vm.isRequestStatus = true;
                                if (angular.isDefined(vm.request.rejectionCodeVO.rejectionCodeDesc)
                                        && vm.request.rejectionCodeVO.rejectionCodeDesc !== ''
                                        && vm.request.rejectionCodeVO.rejectionCodeDesc !== null) {
                                    vm.isRejectedRequest = true;
                                } else {
                                    vm.isRejectedRequest = false;
                                }
                                break;
                            default:
                                vm.isReadOnly = false;
                                vm.isShowNew = false;
                                vm.isShowSave = true;
                                vm.isShowComplete = false;
                                vm.isRequestStatus = true;
                                vm.isResponseComments = true;
                                vm.isRequestComments = false;
                                vm.isRejectedRequest = false;
                                vm.isFileUpload = false;

                                if (vm.request.fileName !== '' && vm.request.fileName !== null) {
                                    vm.isDeleteFile = false;
                                } else {
                                    vm.isDeleteFile = true;
                                }
                                vm.isSubmitted = false;
                                break;
                        }
                        isSearching = false;
                    }
                }

            });
            if (!vm.isAllowedManager) {
                switch (requestVO.status.statusId) {
                    case requestStatus.COMPLETE:
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        vm.isRejectedRequest = false;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = true;
                        break;
                    case requestStatus.REJECT:

                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        if (angular.isDefined(vm.request.rejectionCodeVO.rejectionCodeDesc)
                                && vm.request.rejectionCodeVO.rejectionCodeDesc !== ''
                                && vm.request.rejectionCodeVO.rejectionCodeDesc !== null) {
                            vm.isRejectedRequest = true;
                        } else {
                            vm.isRejectedRequest = false;
                        }
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = true;
                        break;
                    case requestStatus.OPEN :
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        vm.isRejectedRequest = false;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = false;
                        vm.isAllowedManagerResponseComment = true;
                        break;
                    default:
                        vm.isReadOnly = false;
                        vm.isShowNew = false;
                        vm.isShowSave = true;
                        vm.isShowComplete = false;
                        vm.isFileUpload = false;
                        vm.isRequestStatus = true;
                        vm.isRejectedRequest = false;
                        vm.isDeleteFile = false;
                        vm.isSubmitted = false;
                        if (vm.request.fileName !== '' && vm.request.fileName !== null) {
                            vm.isDeleteFile = false;
                        } else {
                            vm.isDeleteFile = true;
                        }
                        break;
                }

            }

            if (angular.isDefined(vm.request.fileName) && vm.request.fileName !== null) {
                vm.isFileName = true;
            }
            if (vm.request.requester !== null && vm.request.requester.phoneNumber !== null) {
                vm.isRequestorPhoneNumber = true;
            }

            if (vm.request.manager !== null && vm.request.manager.phoneNumber !== null) {
                vm.isManagerPhoneNumber = true;
            }


        }

        function uploadDoc() {
            if (vm.myFile) {
                FileService.uploadDoc(vm.myFile, vm.request.requestId, requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME)
                        .then(function (result) {
                            vm.myFile = null;
                            vm.isDownload = true;
                            vm.isDeleteFile = false;
                            vm.request.fileName = result.fileName;
                            growlService.growl(messages.common.fileUploadSuccess, 'success');
                        }).catch(function (error) {
                    growlService.growl(error.data.message, 'danger');
                });
            }
        }


        function download() {
            FileService.download(requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME, vm.request.requestId).success(function () {

            }).error(function () {
                growlService.growl(messages.common.fileDownloadFail, 'danger');
            });

        }


        function deleteFile() {

            FileService.deleteFile(requestTypeConstants.DISASSEMBLYCODE_REQTYPE_NAME, vm.request.requestId)
                    .then(function (result) {
                        growlService.growl(messages.common.fileDeleteSuccess, 'success');
                        vm.isDownload = false;
                        vm.isFileName = false;
                        vm.request.fileName = "";
                    }).catch(function (error) {
                growlService.growl(messages.common.fileDeleteFail, 'danger');
                vm.isDownload = true;
            });
        }

        function validateRequest(request) {

            if (angular.isUndefined(request.disassemblyPrefixVO)) {
                return false;
            }
            if (angular.isUndefined(request.ataVO)) {
                return false;
            }
            if (angular.isUndefined(request.snsSection)) {
                return false;
            }
            if (angular.isUndefined(request.snsSubject)) {
                return false;
            }
            if (angular.isUndefined(request.disAssemblyDCActionVO)) {
                return false;
            }
            if (angular.isUndefined(request.baseTechnicalName)) {
                return false;
            }
            if (angular.isUndefined(request.needByDate)) {
                return false;
            }
            if (angular.isUndefined(request.airplaneModels)) {
                return false;
            }
            if (angular.isUndefined(request.docTypes[0])) {
                return false;
            }
            return true;
        }

        function validateCompleteReject(request) {
            if (request.status.statusId === requestStatus.OPEN) {
                if (angular.isUndefined(request.responseComments)
                        || request.responseComments === null || request.responseComments === '') {
                    return false;
                }
            }

            return true;
        }

        function updateSearchList() {
            $scope.$emit('updateSearchList', {});
        }

        function hasChanges() {
            if (vm.form.$dirty) {
                searchStateService.hasChanges = true;
                return true;
            } else {
                searchStateService.hasChanges = false;
                return false;
            }
        }

        function getLoggedInUser() {
            authService.getUserDetails()
                    .then(function (response) {
                        vm.request.requester = response;
                        vm.loggedInUser = vm.request.requester;
                        if (vm.loggedInUser.phoneNumber !== null) {
                            vm.isRequestorPhoneNumber = true;
                        }
                    }).catch(function (error) {
                growlService.growl(error.message, 'danger');
            });
        }

        function validateDisassemblyCodeVariantCheck(request) {

            if (request.disassemblyCodeVariants.length === 0) {
                return true;
            }

            var check0 = check(request.disassemblyCodeVariants[0], 0);
            if (!check0) {
                return false;
            }

            var check1 = check(request.disassemblyCodeVariants[1], 1);
            if (!check1) {
                return false;
            }

            if (check0 && check1) {
                if (!isEmpty(request.disassemblyCodeVariants[0]) && !isEmpty(request.disassemblyCodeVariants[1]))
                {
                    if (!isEmpty(request.disassemblyCodeVariants[0].disassemblyVariantCode) && !isEmpty(request.disassemblyCodeVariants[1].disassemblyVariantCode))
                    {
                        if (request.disassemblyCodeVariants[0].disassemblyVariantCode === request.disassemblyCodeVariants[1].disassemblyVariantCode) {
                            growlService.growl(messages.disassemblyCode.dupilicateVariantCode, 'danger');
                            return false;
                        } else {
                            var index = 0;
                            if (!isEmpty(request.disassemblyCodeVariants[0].disassemblyVariantCode)) {
                                vm.request.disassemblyCodeVariants[index] = request.disassemblyCodeVariants[0];
                                index++;
                            }
                            if (!isEmpty(request.disassemblyCodeVariants[0])) {
                                vm.request.disassemblyCodeVariants[index] = request.disassemblyCodeVariants[1];
                                index++;
                            }
                            if (index === 0) {
                                vm.request.disassemblyCodeVariants = [];
                            }
                            return true;
                        }
                    }
                }
            }

            if (check0) {
                var index = 0;
                if (!isEmpty(request.disassemblyCodeVariants[0].disassemblyVariantCode)) {
                    vm.request.disassemblyCodeVariants[index] = request.disassemblyCodeVariants[0];
                    index++;
                } else {
                    vm.request.disassemblyCodeVariants = [];
                }
                return true;
            } else if (check1) {
                var index = 0;
                if (!isEmpty(request.disassemblyCodeVariants[0].disassemblyVariantCode)) {
                    vm.request.disassemblyCodeVariants[index] = request.disassemblyCodeVariants[0];
                    index++;
                } else {
                    vm.request.disassemblyCodeVariants = [];
                }
                return true;
            }
        }

        function check(disassemblyCodeVariants, index) {
            if (!isEmpty(disassemblyCodeVariants)) {
                if (isEmpty(disassemblyCodeVariants.disassemblyVariantCode)) {
                    if (isEmpty(disassemblyCodeVariants.disAssemblyVCActionVO)
                            && isEmpty(disassemblyCodeVariants.disassemblyVariantName)
                            && isEmpty(disassemblyCodeVariants.disassemblyVariantInternalName)) {
                        return true;
                    } else {
                        growlService.growl(messages.disassemblyCode.disassemblyCodeVariantCodeMandatory, 'danger');
                        return false;
                    }
                } else {
                    return true;
                }

            } else {
                return true;
            }


        }

        function isEmpty(value) {
            return typeof value == 'string' && !value.trim() || typeof value == 'undefined' || value === null;
        }

        function resetDoctype() {
            if ((angular.isDefined(vm.request.docTypes[0])) && (vm.request.docTypes[0] !== '')) {
                vm.temp[0] = vm.request.docTypes[0];
                vm.request.docTypes = [];
                vm.request.docTypes[0] = vm.temp[0];
            } else {
                vm.request.docTypes = [];
            }
        }

        function populateModel() {
            vm.iterate = false;
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.AIRPLANE_MODEL_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        angular.forEach(response, function (value, key) {
                            if (!vm.iterate) {
                                if (value.airplaneModel === masterTypeConstants.DISASSEMBLY_CODE_MODEL_CONSTANT) {
                                    vm.modelOptions = [value];
                                    vm.request.airplaneModels = vm.modelOptions;
                                    vm.iterate = true;
                                }
                            }
                        });
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
        }

        function validateReject(request) {
            vm.isRejectCode = false;
            if (angular.isUndefined(request.rejectionCodeVO) ||
                    request.rejectionCodeVO.rejectionId === null
                    || request.rejectionCodeVO.rejectionId === ''
                    || request.rejectionCodeVO.rejectionId === 0
                    || request.rejectionCodeVO === 'NO') {
                vm.isRejectCode = true;
                return false;
            }
            return true;
        }
    }

})();


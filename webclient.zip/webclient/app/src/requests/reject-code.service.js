(function () {
    "use strict";
    angular
            .module('gsesp.requests')
            .factory('rejectCodeService', rejectCodeService);
    rejectCodeService.$inject = ['$resource', 'apiHelper'];
    function rejectCodeService($resource, apiHelper) {
        var service = $resource(apiHelper.getRootUrl() + '/rejectCode',
                {},
                {
                    'get': {
                        method: 'GET',
                        isArray: true,
                        params: {
                            requestTypeName: '@requestTypeName',
                            isActive: '@isActive'
                        },
                        url: apiHelper.getRootUrl() + '/rejectCode/:requestTypeName'
                    }
                });
        return service;
    }
})();

(function () {
    'use strict';

    angular.module('gsesp.requests')
            .controller('RejectCodeController', RejectCodeController);

    RejectCodeController.$inject = ['layoutService', '$uibModalInstance', 'parent'];

    function RejectCodeController(layoutService, $uibModalInstance, parent) {
        var vm = this;
        vm.layout = layoutService;
        vm.rejectionCodeVO = {};

        vm.cancel = cancel;
        vm.rejectRequest = rejectRequest;

        initialize();
        function initialize() {
            vm.requestId = parent.request.requestId;
            vm.rejectionCodeOptions = parent.rejectionCodeOptions;
            angular.forEach(vm.rejectionCodeOptions, function (value) {
                if (value.rejectionCodeDesc === 'Other-See Response Comments') {
                    vm.rejectionCodeVO = value;
                }
            });
        }


        function cancel() {
            $uibModalInstance.dismiss('cancel');
        }

        function rejectRequest() {
            $uibModalInstance.close(vm.rejectionCodeVO);
            return vm.rejectionCodeVO;
        }


    }

})();


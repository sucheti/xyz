(function () {
    'use strict';
    angular.module('gsesp')
            .constant('maxNeedByDate',
                    {
                        REQUEST_NEED_BYDATE : 1,
                        TOOL_REQ_NEED_BYDATE : 7
                    })
            .constant('requestTypeConstants',
                    {
                        ACCESSPANEL_REQTYPE_NAME: "accessPanel"
                       ,APPLICABILITY_REQTYPE_NAME: "applicability"
                       ,HAZARDOUSMATERIAL_REQTYPE_NAME: "hazardousMaterials"
                       ,TOOLS_REQTYPE_NAME: "tools"
                        , CAUTION_REQTYPE_NAME: "cautionWarnings"
                        , CIRCUIT_BREAKERS_REQTYPE_NAME: "circuitBreakers"
                        , CONSUMABLES_REQTYPE_NAME: "consumables"
                        , DISASSEMBLYCODE_REQTYPE_NAME: "disassemblyCode"
                        , INFOCODE_REQ_TYPENAME: "infoCode"
                        , SNS_REQTYPE_NAME: "sns"
                        , SOURCE_DATA_REQTYPE_NAME: "sourceData"
                        , ZONES_REQTYPE_NAME: "zones"
                        , ACRONYMSABBREV_REQTYPE_NAME: "acronyms"

                    })
            .constant('requestStatus',
                    {
                        DRAFT : 1,
                        OPEN : 2,
                        COMPLETE : 3,
                        REJECT : 4
                    })
            .constant('requestStatusName',
                    {
                        DRAFT : "Draft"
                    })
            .constant('userRole',
                    {
                        ADMIN : 2,
                        REQUESTER : 1
                    })
            .constant('paginationDetails',
                    {
                        PAGE_COUNT : 10,
                        CURRENT_PAGE : 1,
                        NO_OF_PAGES : 4
                    });
})();

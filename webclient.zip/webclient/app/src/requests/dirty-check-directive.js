(function (){
    "use strict";

    angular.module('gsesp.requests')
            .directive('dirtyCheck',['$state','messages',function ($state,messages){
                    return {
                        restrict : 'A',
                        require : '^form',
                        link : function (scope,element,attrs,ctrl){
                            var excludedStatesList = [];
                            scope.$on('$stateChangeStart',function (event,next,current){
                                if(angular.isDefined(attrs.excludedstates)){
                                    excludedStatesList = attrs.excludedstates.split(",");
                                    if(excludedStatesList.indexOf(next.name) <= -1){
                                        dirtyCheck(event,next);
                                    }
                                } else{
                                    dirtyCheck(event,next);
                                }
                            });

                            window.onbeforeunload = function (event){
                                if(ctrl.$dirty){
                                    var message = 'Sure you want to leave?';
                                    if(typeof event === 'undefined'){
                                        event = window.event;
                                    }
                                    if(event){
                                        event.returnValue = message;
                                    }
                                    return message;
                                }
                            };

                            function dirtyCheck(event,next){
                                if(!ctrl.$submitted || ctrl.$invalid){
                                    if(ctrl.$dirty){
                                        ctrl.$submitted = true;
                                        event.preventDefault();
                                        swal({
                                            title : messages.common.dirtyAlertTitleMessage,
                                            text : messages.common.nonRecoverTextMessage,
                                            type : "warning",
                                            showCancelButton : true,
                                            confirmButtonColor : "#DD6B55",
                                            confirmButtonText : "OK",
                                            closeOnConfirm : true
                                        },function (response){
                                            if(response){
                                                ctrl.$invalid = false;
                                                if(next.redirectTo !== "undefined" && next.redirectTo === $state.current.name){
                                                    $state.reload();
                                                } else{
                                                    ctrl.$invalid = false;
                                                    $state.go(next.name);
                                                }

                                            } else{
                                                ctrl.$submitted = false;
                                            }
                                        });
                                    }
                                }
                            }
                        }
                    };
                }]);
})();
(function (){
    'use strict';
    
    angular.module('gsesp.requests')
            .controller('RequestsController',RequestsController);
    
    RequestsController.$inject = ['$scope','layoutService'];
    
    function RequestsController($scope,layoutService){
        var vm = this;
        vm.layout = layoutService;        


        $scope.$on('updateSearchList',function (event){
            $scope.$broadcast('query',{});
        });
        $scope.$on('isCheckFormDirty',function (event){
            $scope.$broadcast('isFormDirty',{});
        });

    }
})();



(function () {
    'use strict';

    angular.module('gsesp.applicabilities', [
        'ui.bootstrap',
        'gsesp.coc'
    ]);
})();


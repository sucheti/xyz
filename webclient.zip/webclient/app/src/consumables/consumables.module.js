(function () {
    'use strict';

    angular.module('gsesp.consumables', [
        'ui.bootstrap'
    ]);
})();

(function () {
    'use strict';

    angular.module('gsesp', [
        'app.core',
        'app.layout',
        'ngTable',
        'localytics.directives',
        'ui.bootstrap',
        'angular.chosen',
        'ui.bootstrap',
        /*
         * Feature areas
         */
        'gsesp.requests',
        'gsesp.master',
        'gsesp.auth',
        'gsesp.admin',
        'gsesp.file' 
    ]);
})();


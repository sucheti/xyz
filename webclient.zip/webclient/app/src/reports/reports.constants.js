(function () {
    'use strict';
    angular.module('gsesp')
            .constant('templateName', {
                ACCESSPANEL_REPORT_NAME: "Access Panel  Report",
                APPLICABILITY_REPORT_NAME: "Applicabilities Report",
                CAUTIONWARNINGS_REPORT_NAME: "Caution Warnings Report",
                HAZARDOUS_MATERIALS_REPORT_NAME: "Hazardous Materials Report",
                TOOLREQUIREMENTS_REPORT_NAME: "Tool Requirements Report",
                CIRCUIT_BREAKERS_REPORT_NAME: "Circuit Breakers Report",
                CONSUMABLES_REPORT_NAME: "Consumables Report",
                DISASSEMBLY_CODE_REPORT_NAME: "Disassembly Code Report",
                INFOCODE_REPORT_NAME: "Infocode Report",
                SNS_REPORT_NAME: "SNS Report",
                SOURCE_DATA_REPORT_NAME: "Source Data Report",
                ZONES_REPORT_NAME: "Zones Report",
                ACRONYMS_REPORT_NAME: "Acronyms Abbreviations Report"
            });
})();

(function () {
    'use strict';

    angular.module('gsesp.requests')
            .controller('ReportModalController', ReportModalController);

    ReportModalController.$inject = ['$scope', '$uibModalInstance', 'ReportsService', 'parent'];

    function ReportModalController($scope, $uibModalInstance, ReportsService, parent) {
        var vm = this;
        vm.reportStatus = {};
        vm.ok = ok;
        vm.cancel = cancel;
        initialize();
        function initialize() {
            vm.reportStatus.isOpen = true;
            vm.isPdf = true;
        }
        function ok() {
            var statusParameter = {};

            if (vm.isPdf && vm.isxlsx) {
                statusParameter = {"reportName": parent.reportName,
                    "isPdf": true,
                    "isXlsx": false,
                    "reportParameters": [{"parameterName": "Open", "parameterValue": vm.reportStatus.isOpen},
                        {"parameterName": "Completed", "parameterValue": vm.reportStatus.isCompleted},
                        {"parameterName": "Draft", "parameterValue": vm.reportStatus.isDraft},
                        {"parameterName": "Rejected", "parameterValue": vm.reportStatus.isReject}
                    ]};
                ReportsService.runReport(statusParameter);
                statusParameter = {"reportName": parent.reportName,
                    "isPdf": false,
                    "isXlsx": true,
                    "reportParameters": [{"parameterName": "Open", "parameterValue": vm.reportStatus.isOpen},
                        {"parameterName": "Completed", "parameterValue": vm.reportStatus.isCompleted},
                        {"parameterName": "Draft", "parameterValue": vm.reportStatus.isDraft},
                        {"parameterName": "Rejected", "parameterValue": vm.reportStatus.isReject}
                    ]};
                ReportsService.runReport(statusParameter);
            } else {
                statusParameter = {"reportName": parent.reportName,
                    "isPdf": vm.isPdf,
                    "isXlsx": vm.isxlsx,
                    "reportParameters": [{"parameterName": "Open", "parameterValue": vm.reportStatus.isOpen},
                        {"parameterName": "Completed", "parameterValue": vm.reportStatus.isCompleted},
                        {"parameterName": "Draft", "parameterValue": vm.reportStatus.isDraft},
                        {"parameterName": "Rejected", "parameterValue": vm.reportStatus.isReject}
                    ]};
                ReportsService.runReport(statusParameter);
            }

            $uibModalInstance.dismiss('cancel');
        }

        function cancel() {
            $uibModalInstance.dismiss('cancel');
        }
    }
})();
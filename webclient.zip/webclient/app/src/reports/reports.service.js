(function () {
    'use strict';
    angular
            .module('gsesp.requests')
            .factory('ReportsService', ReportsService);
    ReportsService.$inject = ['$http', 'apiHelper','templateName'];
    function ReportsService($http, apiHelper,templateName) {
        var baseUrl = apiHelper.getRootUrl();
        var service = {
            runReport: runReport
        };
        return service;


        function runReport(reportTemplateVO) {
            var url = baseUrl + '/gsesp/report/generate';
            var data = reportTemplateVO; 
            $http.post(url, data, {responseType: "arraybuffer"}).success(
                    function (response, status, headers) {
                        var type = headers()['content-type'];
                        var disposition = headers()['content-disposition'];
                        if (disposition) {
                            var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                            if (match[1])
                                var defaultFileName = match[1];
                        }
                        defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                        var blob = new Blob([response], {type: type});
                        saveAs(blob, defaultFileName);
                    });
        }
    }

})();



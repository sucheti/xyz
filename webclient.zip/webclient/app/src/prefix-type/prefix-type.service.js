(function () {
    'use strict';

    angular
            .module('gsesp.prefixType')
            .factory('prefixTypeService', prefixTypeService);

    prefixTypeService.$inject = ['$http', 'apiHelper'];

    function prefixTypeService($http, apiHelper) {

        var service = {
            getAllPrefixTypeOption: getAllPrefixTypeOption
        };

        return service;


        function getAllPrefixTypeOption() {
            return $http.get('src/prefix-type/data/prefix-type.json')
                    .then(getAllPrefixTypeOptionSuccess);

            function getAllPrefixTypeOptionSuccess(response) {
                return response.data;
            }
        }


    }
})();



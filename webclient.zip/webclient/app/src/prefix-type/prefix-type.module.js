(function () {
    'use strict';

    angular.module('gsesp.prefixType', [
        'ui.bootstrap'
    ]);
})();
(function (){
    'use strict';

    angular.module('gsesp.access-panels',[
        'ui.bootstrap'
    ]);
})();


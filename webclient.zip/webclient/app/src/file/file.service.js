(function () {
    "use strict";
    angular
            .module('gsesp.file')
            .factory('FileService', FileService);
    FileService.$inject = ['$http', 'apiHelper', 'Upload'];
    function FileService($http, apiHelper, Upload) {

        return {
            uploadDoc: uploadDoc,
            deleteFile: deleteFile,
            download: download
        };
        function uploadDoc(file, requestId, requestTypeName)
        {
            return Upload.upload({
                url: apiHelper.getRootUrl() + '/requestType/' + requestTypeName + '/request/' + requestId + '/upload',
                data:
                        {
                            file: file,
                            'requestId': requestId,
                            'requestTypeName': requestTypeName
                        }
            }).then(uploadComplete).catch(uploadFailed);

            function uploadComplete(response) {
                return response.data;
            }

            function uploadFailed(error) {
                throw error.data;
            }

        }


        function deleteFile(requestTypeName, requestId)
        {
            return $http.delete(apiHelper.getRootUrl() + '/requestType/' + requestTypeName + '/deleteFile/' + requestId)
                    .then(deleteFileSuccess)
                    .catch(deleteFileFailure);

            function deleteFileSuccess(response) {
                return response.data;
            }

            function deleteFileFailure(error) {
                // handle error
                throw error.data;
            }
        }
        function download(requestTypeName, requestId) {
            var url = apiHelper.getRootUrl() + '/requestType/' + requestTypeName + '/download/' + requestId;
            var data;
            return $http.post(url, data, {responseType: "arraybuffer"}).success(
                    function (response, status, headers) {
                        var type = headers()['content-type'];
                        var disposition = headers()['content-disposition'];
                        if (disposition) {
                            var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                            if (match[1])
                                var defaultFileName = match[1];
                        }
                        defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                        var blob = new Blob([response], {type: type});
                        saveAs(blob, defaultFileName);
                    }).error(function (error) {
                throw error;
            });
        }
    }
})();

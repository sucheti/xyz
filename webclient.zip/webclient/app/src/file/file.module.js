(function (){
    'use strict';

    angular.module('gsesp.file',[
        'ui.bootstrap',
        'ngFileUpload'
    ]);
})();


(function () {
    'use strict';

    angular.module('gsesp.cautions-warnings', [
        'ui.bootstrap',
        'gsesp.coc'
    ]);
})();


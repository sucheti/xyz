(function () {
    'use strict';
    angular.module('gsesp.cautions-warnings')
            .constant('cautionConstants', {
                IS_ACTIVE: 1,
                CAUTION_FALSE: 2,
                CAUTION_TRUE: 1
            });
})();
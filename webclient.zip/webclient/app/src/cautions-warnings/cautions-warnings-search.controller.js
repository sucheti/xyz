(function () {
    'use strict';

    angular.module('gsesp.cautions-warnings')
            .controller('CautionsWarningsSearchController', CautionsWarningsSearchController);

    CautionsWarningsSearchController.$inject = ['messages', '$scope', '$stateParams', '$state', 'requestsService', 'searchStateService', 'growlService', 'requestTypeConstants', 'paginationDetails'];

    function CautionsWarningsSearchController(messages, $scope, $stateParams, $state, requestsService, searchStateService, growlService, requestTypeConstants, paginationDetails) {
        var vm = this;
        vm.queryParams = {};
        vm.searchResults = {};
        vm.pagination = {};
        vm.isSearchResultsEmpty = true;
        vm.query = query;
        vm.search = search;
        vm.get = get;
        vm.initialize = initialize;
        vm.pageChanged = pageChanged;
        vm.searchRequestParam = searchRequestParam;
        vm.doPaginationBySearchResults = doPaginationBySearchResults;


        initialize();

        function initialize() {
            vm.pagination = {
                        currentPage: paginationDetails.CURRENT_PAGE,
                        noOfPages: paginationDetails.NO_OF_PAGES,
                        entryLimit: paginationDetails.PAGE_COUNT
                    };
                    
            if ((angular.isUndefined($stateParams.requestId) || $stateParams.requestId === '')
                    && !searchStateService.isNewRequest) {
                searchStateService.state = {};
                searchStateService.filters = {};
                searchStateService.queryFilters = {};
                searchStateService.isNewRequest = false;
                searchStateService.searchRequestId = '';
            }
            if (angular.equals(searchStateService.state, {})) {
                if(angular.equals(searchStateService.filters, {})){
                vm.filters = {
                    isOpen: true,
                    isDraft: false,
                    isRejected: false,
                    isCompleted: false
                };
                vm.originalFilters = {
                    isOpen: true,
                    isDraft: false,
                    isRejected: false,
                    isCompleted: false
                };
                    
                }else{
                    if(angular.equals(searchStateService.queryFilters,{})){
                        searchStateService.queryFilters = {
                            isOpen : true,
                            isDraft : false,
                            isRejected : false,
                            isCompleted : false
                        };
                    }
                    vm.originalFilters = angular.copy(searchStateService.queryFilters);
                    vm.originalSearchReqId =  angular.copy(searchStateService.queryRequestId);
                }
                vm.originalpagination = angular.copy(vm.pagination);
                query();
            } else {
                vm.searchResults = searchStateService.state;
                vm.filters = searchStateService.filters;
                vm.pagination = searchStateService.pagination;
                vm.isSearchResultsEmpty = true;
                if(vm.pagination.totalItems > vm.pagination.entryLimit){
                vm.isSearchResultsEmpty = false;
                }
                if (searchValidate()) {
                    vm.searchRequestId = angular.copy(searchStateService.searchRequestId);
                }
            }
        }

        function pageChanged() {
            vm.originalpagination =  angular.copy(vm.pagination);
            query();
        }

        $scope.$on('query', function (event) {
            
             if (searchValidate()) {
                vm.searchRequestId = angular.copy(searchStateService.searchRequestId);
            }
            vm.originalpagination =  angular.copy(vm.pagination);
            query();
            vm.filters = angular.copy(searchStateService.filters);
            vm.pagination = angular.copy(searchStateService.pagination);
            vm.isSearchResultsEmpty = false;
        });

        function search() {
            vm.originalSearchResults = angular.copy(vm.searchResults);
            vm.originalFilters =  angular.copy(vm.filters);
            vm.originalpagination =  angular.copy(vm.pagination);
            vm.originalSearchReqId =  angular.copy(vm.searchRequestId);
            searchStateService.queryRequestId =angular.copy( vm.searchRequestId);
            searchStateService.queryFilters=angular.copy(vm.filters);
            query();
        }
        
        function query() {

            if (searchValidate()) {
                vm.queryParams = {
                    requestTypeName: requestTypeConstants.CAUTION_REQTYPE_NAME,
                    requestId: vm.originalSearchReqId,
                    isOpen: vm.originalFilters.isOpen,
                    isDraft: vm.originalFilters.isDraft,
                    isRejected: vm.originalFilters.isRejected,
                    isCompleted: vm.originalFilters.isCompleted,
                    pageNumber: vm.originalpagination.currentPage,
                    pageCount: paginationDetails.PAGE_COUNT
                };
                requestsService.query(vm.queryParams,
                        function (response) {
                            doPaginationBySearchResults(response);
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
            } else {
                growlService.growl(messages.common.searchValidateMessage, 'danger');
            }
        }

        function doPaginationBySearchResults(response) {
            vm.pagination.totalItems = response.totalCount;
            vm.searchResults = response.requestResultVO;
             vm.isSearchResultsEmpty = true;
            if(vm.pagination.totalItems > vm.pagination.entryLimit){
                vm.isSearchResultsEmpty = false;
            }
            searchStateService.state = vm.searchResults;
           if (angular.isUndefined(vm.filters) || vm.filters === null || vm.filters === '') {
               vm.filters =searchStateService.filters;
           }
            searchStateService.filters = vm.filters;
          
            searchStateService.pagination = vm.pagination;
            if (angular.isUndefined(vm.searchRequestId) || vm.searchRequestId === null || vm.searchRequestId === '') {
                vm.searchRequestId =angular.copy(searchStateService.searchRequestId);
            }
            searchStateService.searchRequestId = angular.copy(vm.searchRequestId);
        }



        function get(requestId) {
            if ($stateParams.requestId !== requestId.toString()) {
                $scope.$emit('isCheckFormDirty', {});
                if (searchStateService.hasChanges) {
                    swal({
                        title: messages.common.dirtyAlertTitleMessage,
                        text: messages.common.nonRecoverTextMessage,
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Proceed",
                        closeOnConfirm: true
                    }, function () {
                        getConfirm(requestId);
                    });
                } else {
                    getConfirm(requestId);
                }
            }
        }

        function searchValidate() {
            if (angular.isDefined(vm.searchRequestId) && vm.searchRequestId !== null && vm.searchRequestId !== '') {
               searchStateService.searchRequestId = angular.copy(vm.searchRequestId);
                if (parseInt(vm.searchRequestId)) {
                    return true;
                } else {
                    searchStateService.searchRequestId = '';
                    vm.searchRequestId = null;
                    return true;
                }

                return false;
            }
            return true;
        }

        function getConfirm(requestId) {
            $state.go('request.cautions', {requestId: requestId});
            searchStateService.filters = vm.filters;
            searchStateService.pagination = vm.pagination;
            vm.isSearchResultsEmpty = true;
            if(vm.pagination.totalItems > vm.pagination.entryLimit){
                vm.isSearchResultsEmpty = false;
            }
            searchStateService.state = vm.searchResults;
            if (searchValidate()) {
                searchStateService.searchRequestId = angular.copy(vm.searchRequestId);
            } else {
                searchStateService.searchRequestId = '';
            }
        }
        function searchRequestParam() {
            if (searchValidate()) {
               searchStateService.searchRequestId = angular.copy(vm.searchRequestId);
            } else {
                searchStateService.searchRequestId = '';
            }
        }

    }
})();

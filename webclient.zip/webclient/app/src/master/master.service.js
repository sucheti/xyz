(function () {
    "use strict";
    angular
            .module('gsesp.master')
            .factory('masterService', masterService);
    masterService.$inject = ['$resource', 'apiHelper'];
    function masterService($resource, apiHelper) {
        var service = $resource(apiHelper.getRootUrl(),
                {},
                {
                    'getAll': {
                        method: 'GET',
                        isArray: true,
                        url: 'src/admin/update-master-data/data/admin-master-data.json'
                    },
                    'query': {
                        method: 'GET',
                        isArray: true,
                        params: {
                            masterTypeName: '@masterTypeName'
                        },
                        url: apiHelper.getRootUrl() + '/:masterTypeName'
                    },
                    'get': {
                        method: 'GET',
                        isArray: true,
                        params: {
                            masterTypeName: '@masterTypeName',
                            responsibleGroupName: '@responsibleGroupName'
                        },
                        url: apiHelper.getRootUrl() + '/:masterTypeName/:responsibleGroupName'
                    },
                    'add': {
                        method: 'POST',
                        params: {
                            masterTypeName: '@masterTypeName'
                        },
                        url: apiHelper.getRootUrl() + '/:masterTypeName'
                    },
                    'update': {
                        method: 'PUT',
                        params: {
                            masterTypeName: '@masterTypeName',
                            masterItemId: '@masterItemId'
                        },
                        url: apiHelper.getRootUrl() + '/:masterTypeName/:masterItemId'
                    },
                    'delete': {
                        method: 'DELETE',
                        params: {
                            masterTypeName: '@masterTypeName',
                            masterItemId: '@masterItemId'
                        },
                        url: apiHelper.getRootUrl() + '/:masterTypeName/:masterItemId'
                    },
                    'getAllEngineType': {
                        method: 'GET',
                        params: {
                            masterTypeName: '@masterTypeName'
                        },
                        url: apiHelper.getRootUrl() + '/:masterTypeName/all'
                    }
                });
        return service;
    }
})();
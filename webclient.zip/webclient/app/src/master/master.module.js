(function (){
    'use strict';

    angular.module('gsesp.master',[
    ]);
})();



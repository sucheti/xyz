(function () {
    'use strict';
    angular.module('gsesp.admin.search')
            .controller('AdminAddController', AdminAddController);
    AdminAddController.$inject = ['NgTableParams', '$state', 'adminDataService', 'growlService', 'messages', 'layoutService','foreignPersonStatus','userStatus'];
    function AdminAddController(NgTableParams, $state, adminDataService, growlService, messages, layoutService, foreignPersonStatus, userStatus) {

        var vm = this;
        vm.layout = layoutService;
        vm.tableParams = {
            page: 1, // show first page
            count: 5 // count per page
        };

        vm.selectedUser;
        vm.userResponse = [];
        vm.errorMessage = "";
        vm.format = 'dd-MM-yyyy';
        vm.name = false;
        vm.isId = false;
        vm.error = false;
        vm.showAdd = false;
        vm.dataLength = [];
        vm.query = [];
        vm.clearSearch = clearSearch;
        vm.queryUsers = queryUsers;
        vm.displayErrorMessage = displayErrorMessage;
        vm.addUser = addUser;
        vm.disableFields = disableFields;


        vm.isCollapsed = {
            searchResults: true
        };

        vm.cardSections = {
            addUser: {id: "addUser", title: "Search Boeing User", isCollapsed: false}
        };

        function displayErrorMessage() {
            vm.errorMessage = "";
        }
        function initializeAddUserTable(data) {
            if (data !== undefined) {
                vm.showAdd = true;
                if (data.length >= 5 && data.length <= 10) {
                    vm.dataLength = [5, 10];
                } else if (data.length >= 11 && data.length <= 15) {
                    vm.dataLength = [5, 10, 15];
                } else if (data.length >= 16) {
                    vm.dataLength = [5, 10, 15, 20];
                } else {
                    vm.dataLength = [];
                }
            }
            vm.addUserTableParams = {};
            vm.addUserColumns = [
                {field: "selector", title: ""},
                {field: "bemsId", valueExpr: "item.user.bemsId", title: "BEMS ID", filter: {"user.bemsId": "text"}, sortable: "user.bemsId"},
                {valueExpr: "item.user.firstName", title: "FIRST NAME", filter: {"user.firstName": "text"}, sortable: "user.firstName"},
                {valueExpr: "item.user.middleName", title: "MIDDLE INITIAL", filter: {"user.middleName": "text"}, sortable: "user.middleName"},
                {valueExpr: "item.user.lastName", title: "LAST NAME", filter: {"user.lastName": "text"}, sortable: "user.lastName"},
                {valueExpr: "item.user.emailAddress", title: "EMAIL", filter: {"user.emailAddress": "text"}, sortable: "user.emailAddress"}
            ];
            
            vm.addUserTableParams = new NgTableParams({
                page: 1, // show first page
                count: 5 // count per page
            }, {
                counts: vm.dataLength,
                dataset: data
            });
        }


        function queryUsers() {
            vm.showAdd = false;
            initializeAddUserTable();
            if (validate(vm.query)) {
                if (vm.query.bemsId) {
                    if (!isNaN(vm.query.bemsId) || vm.query.bemsId === undefined) {
                        searchBoeingUserswithBemsId();
                        vm.isCollapsed.searchResults = false;
                    } else {
                        growlService.growl(messages.searchBoeingUsers.bemsIdNumericErrorMessage, 'danger');
                        vm.error = true;
                        vm.isCollapsed.searchResults = true;
                    }

                } else if (vm.query.firstName || vm.query.lastName) {
                    searchBoeingUserswithName();
                    vm.isCollapsed.searchResults = false;
                }
            }
        }

        function clearSearch() {
            vm.isCollapsed.searchResults = true;
            initializeAddUserTable();
            vm.query.bemsId = null;
            vm.query.firstName = null;
            vm.query.lastName = null;
            vm.toolSelectedRow = null;
            vm.name = false;
            vm.isId = false;
            vm.error = false;
            vm.dataLength = [];

        }

        function searchBoeingUserswithBemsId() {

            adminDataService.searchBoeingUsersWithBemsId(vm.query.bemsId)
                    .success(function (result) {

                        vm.userResponse = result;
                        var userResults = [];
                        var profileholder = vm.userResponse.resultholder.profiles.profileholder;
                        if (profileholder.length > 0) {
                            userResults = profileholder;
                        } else {
                            userResults.push(profileholder);
                        }
                        initializeAddUserTable(userResults);
                    }).error(function (error) {

                growlService.growl(error.data.message, "danger");
            });
        }

        function searchBoeingUserswithName() {

            adminDataService.searchBoeingUsersWithName(vm.query.firstName, vm.query.lastName)
                    .success(function (result) {

                        vm.userResponse = result;
                        var userResults = [];
                        var profileholder = vm.userResponse.resultholder.profiles.profileholder;
                        if (profileholder.length > 0) {
                            userResults = profileholder;
                        } else {
                            userResults.push(profileholder);
                        }
                        initializeAddUserTable(userResults);
                    }).error(function (error) {

                growlService.growl(error.data.message, "danger");
            });
        }

        function validate(data)
        {

            if (data === null || data === undefined)
            {

                growlService.growl(messages.searchBoeingUsers.mandatoryFieldErrorMessage, 'danger');
                return false;
            }
            if (!data.bemsId && !data.firstName && !data.lastName)
            {

                growlService.growl(messages.searchBoeingUsers.mandatoryFieldErrorMessage, 'danger');
                return false;
            }

            return true;
        }
        function disableFields()
        {
            if (vm.query.bemsId)
            {
                vm.name = true;
            }
            if (vm.query.bemsId === '')
            {
                vm.name = false;
            }
            if (vm.query.firstName || vm.query.lastName)
            {
                vm.isId = true;
            }
            if (vm.query.firstName === '' || vm.query.lastName === '')
            {
                vm.isId = false;
            }
        }

        function addUser(data) {
            var isSuccess = false;
            var foreignPerson;
            var status;
            if (data === null || data === undefined) {
                growlService.growl(messages.admin.userNotSelected,'danger');
            } else {
                vm.bemsId = data.user.bemsId;
                adminDataService.validateUser(vm.bemsId).then(function (result) {
                    isSuccess = result;
                    if(data.user.usPersonStatusString === 'FOREIGN PERSON'){
                        foreignPerson = foreignPersonStatus.FOREIGN_PERSON;
                    }else {
                        foreignPerson = foreignPersonStatus.US_PERSON;
                    }
                    if(data.user.status === 'ACTIVE'){
                        status = userStatus.ACTIVE;
                    }else {
                        status = userStatus.INACTIVE;
                    }
                    if (!isSuccess) {
                        var params = {bemsId: data.user.bemsId, firstName: data.user.firstName, middleInitial: data.user.middleName, lastName: data.user.lastName,
                            email: data.user.emailAddress, phoneNumber: data.user.phone, foreignPerson: foreignPerson, isActive: status };
                        adminDataService.addUser(params).then(function (result) {
                            $state.go('administration.assign', {bemsId: vm.bemsId});
                        }).catch(function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
                    } else {
                        $state.go('administration.assign', {bemsId: vm.bemsId});
                    }

                }).catch(function (error) {
                    growlService.growl(error.data.message, 'danger');
                });
            }
        }

    }
})();


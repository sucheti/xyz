(function () {
    'use strict';

    angular
            .module('gsesp.admin.search')
            .factory('adminDataService', adminDataService);

    adminDataService.$inject = ['$http', 'apiHelper'];

    function adminDataService($http, apiHelper) {
        var baseUrl = apiHelper.getRootUrl();
        var service = {
            addUser: addUser,
            validateUser: validateUser,
            searchBoeingUsersWithBemsId: searchBoeingUsersWithBemsId,
            searchBoeingUsersWithName: searchBoeingUsersWithName,
            searchGsepUsers: searchGsepUsers,
            getListManager: getListManager,
            getReponsibleGroups: getReponsibleGroups,
            getUserForBemsId: getUserForBemsId,
            updateManagerDetials: updateManagerDetials
        };

        return service;


        function getReponsibleGroups() {
            return $http.get(baseUrl + '/user/leadGroups')
                    .then(getReponsibleGroupsSuccess);

            function getReponsibleGroupsSuccess(response) {
                return response.data;
            }
        }

        function getUserForBemsId(bemsId) {
            return $http.get(baseUrl + '/user/' + bemsId)
                    .then(getUserForBemsIdSuccess);

            function getUserForBemsIdSuccess(response) {
                return response.data;
            }
        }

        function updateManagerDetials(managerUpdate) {
            return $http.put(baseUrl + '/user/', managerUpdate)
                    .then(querySuccess)
                    .catch(queryFailure);
            function querySuccess(response) {
                return response.data;
            }
            function queryFailure(error) {
                throw error;
            }
        }

        function searchBoeingUsersWithBemsId(bemsId) {

            var url = "https://insite.web.boeing.com/culture/service/boeingUserWebServiceJSON/bemsid?callback=JSON_CALLBACK";
            var responsePromise = $http.jsonp(url,
                    {
                        params: {
                            query: bemsId
                        }
                    }
            );
            return responsePromise;
        }

        function searchBoeingUsersWithName(firstName, lastName) {
            var inputParam;
            if (firstName && lastName) {
                inputParam = lastName + ',' + firstName;
            } else if (firstName) {
                inputParam = ',' + firstName;
            } else if (lastName) {
                inputParam = lastName + ',';
            }
            var url = "https://insite.web.boeing.com/culture/service/boeingUserWebServiceJSON/name?callback=JSON_CALLBACK";
            var responsePromise = $http.jsonp(url,
                    {
                        params: {
                            query: inputParam,
                            limit: 1000,
                            order: "bemsid"
                        }
                    }
            );
            return responsePromise;
        }

        function addUser(param) {
            return $http.post(baseUrl + '/user/', param)
                    .then(querySuccess)
                    .catch(queryFailure);
            function querySuccess(response) {
                return response;
            }
            function queryFailure(error) {
                throw error;
            }
        }

        function validateUser(bemsId) {
            return $http.get(baseUrl + '/user/validate/' + bemsId)
                    .then(validateUsersSuccess)
                    .catch(validateUsersFailure);
            function validateUsersSuccess(response) {
                return response.data;
            }
            function validateUsersFailure(error) {
                throw error;
            }
        }

        function searchGsepUsers(params) {
            return $http.get(baseUrl + '/user', {params: params}
            ).then(searchGsespUsersSuccess).catch(searchGsespUsersFailure);
            function searchGsespUsersSuccess(response) {
                return response.data;
            }
            function searchGsespUsersFailure(error) {
                throw error;
            }
        }

        function getListManager() {
            return $http.get(baseUrl + '/user/managerItem/')
                    .then(getListManagerSuccess);

            function getListManagerSuccess(response) {
                return response.data;
            }
        }
    }
})();



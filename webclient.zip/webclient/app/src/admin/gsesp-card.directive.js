(function () {
    "use strict";

    angular
            .module('gsesp.admin')
            .directive('gsespCard', gsespCard);
    function gsespCard() {
        return {
            restict: 'E',
            scope: {},
            bindToController: {
                headerTitle: '@',
                isCollapsed: '=',
                editMode: '=',
                actions: '=',
                actionTooltip: '@',
                add: '&',
                edit: '&',
                delete: '&'
            },
            transclude: true,
            templateUrl: 'src/admin/gsesp-card.template.html',
            controller: GsespCardController,
            controllerAs: 'vm'
        };
    }

    function GsespCardController() {
        var vm = this;
        vm.collapseClick = collapseClick;

        // click event to collapse card
        function collapseClick(event) {
            vm.isCollapsed = !vm.isCollapsed;
            event.stopPropagation();
        }
    }
})();
(function () {
    'use strict';

    angular.module('gsesp.admin', [
        'materialAdmin',
        'gsesp.admin.search',
        'gsesp.admin.update-master'
    ]);
})();





(function () {
    'use strict';

    angular.module('gsesp.admin.update-master', [
        'ui.bootstrap'
    ]);
})();

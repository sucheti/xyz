(function () {
    'use strict';

    angular.module('gsesp.admin.update-master')
            .controller('AdminUpdateMasterController', AdminUpdateMasterController);
    AdminUpdateMasterController.$inject = ['NgTableParams', 'layoutService', '$scope', '$filter', 'growlService', 'authService', 'masterService', 'masterTypeConstants', 'messages', 'fieldLengthConstants'];

    function AdminUpdateMasterController(NgTableParams, layoutService, $scope, $filter, growlService, authService, masterService, masterTypeConstants, messages, fieldLengthConstants) {

        var vm = this;
        vm.masterTables = [];
        vm.managerOptions = [];
        vm.layout = layoutService;
        vm.model = [];
        vm.isEditing = false;
        vm.isCreate = false;
        vm.enbaleSelectRow = false;//To enable or disable the selected row
        vm.title = "";
        vm.module = "";
        vm.selectedRow = {};
        $scope.newTableObj = {};
        vm.actualSelectedRow = {};
        vm.masterItemId = {};
        vm.manager = [];
        vm.tableParams = {
            page: 1, // show first page
            count: 5 // count per page
        };
        vm.isCollapsed = {
            results: true
        };
        vm.isRejected = true;
        vm.isdisplayRejection = false;
        vm.iterate = false;
        vm.isDirtyAlert = true;
        vm.displayMaster = [];
        vm.displayMasterTable = [];
        vm.enableIsActive = true;

        vm.displayGrid = displayGrid;
        vm.editMasterData = editMasterData;
        vm.deleteMasterData = deleteMasterData;
        vm.saveMasterData = saveMasterData;
        vm.addMasterData = addMasterData;
        vm.cancelChanges = cancelChanges;
        vm.selectRow = selectRow;
        vm.setDefaultManagerItems = setDefaultManagerItems;
        initialize();

        function initialize() {
            vm.loggedInUser = {};
            vm.master = {};
            vm.master.getModifiedBy = {};
            $scope.newTableObj.code = {};
            authService.getUserDetails()
                    .then(function (response) {
                        vm.master.getModifiedBy = response;
                        vm.loggedInUser = vm.master.getModifiedBy;
                    });
            masterService.getAll(
                    function (response) {
                        vm.masterTables = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
        }


        function displayGrid() {
            vm.isCollapsed.results = false;
            vm.master = {};
            vm.enbaleSelectRow = false;
            if ((vm.form.$submitted) || vm.form.$invalid) {
                if (vm.form.$dirty) {
                    swal({
                        title: messages.common.dirtyAlertTitleMessage,
                        text: messages.common.nonRecoverTextMessage,
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Ok",
                        closeOnConfirm: true
                    }, function (confirm) {
                        if (confirm) {
                            vm.form.$dirty = false;
                            getMasterData();
                        } else {
                            if (vm.masterTable.code !== vm.displayMasterTable.code) {
                                vm.masterTable = angular.copy(vm.displayMasterTable);
                                var page = vm.masterTableParams.page(1);
                                vm.masterTableParams.reload();
                                page = vm.masterTableParams.page();

                            }
                        }
                    });
                } else {
                    getMasterData();
                    vm.displayMasterTable = angular.copy(vm.masterTable);
                }
            } else {
                getMasterData();
            }
        }

        function getMasterData() {
            return masterService.query(
                    {
                        masterTypeName: vm.masterTable.code,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.master = response;
                        if (vm.masterTable.code === masterTypeConstants.REJECTION_CODE) {
                            setDefaultManagerItems();
                        }
                        initializeMaster(response);
                        vm.isEditing = false;

                    },
                    function (error) {
                        throw error.message;
                    });
        }
        function addMasterData() {
            vm.isCreate = true;
            vm.isEditing = true;
            vm.isEdit = false;
            vm.isRejected = true;
            vm.form.$submitted = false;
            vm.enableIsActive = false;
            vm.enbaleSelectRow = true;


            $scope.newTableObj.modifiedBy = {};
            $scope.newTableObj = createNewObj(vm.masterTable.code);
            vm.master.splice(0, 0, $scope.newTableObj);
            var page = vm.masterTableParams.page(1);
            vm.masterTableParams.reload();
            page = vm.masterTableParams.page();
            $scope.newTableObj.modifiedBy = vm.loggedInUser;
        }
        function editMasterData() {
            vm.form.$submitted = false;
            if (angular.isUndefined(vm.selectedRow.active)) {
                growlService.growl(messages.common.editMasterFields, 'danger');
            } else {
                vm.isEditing = true;
                vm.isCreate = false;
                vm.isEdit = true;
                vm.enbaleSelectRow = true;


                //selectRow(vm.selectedRow);
                $scope.newTableObj = createNewObj(vm.masterTable.code);
                $scope.newTableObj = vm.actualSelectedRow;
                if (vm.selectedRow !== 0) {
                    $scope.newTableObj.enableActive = false;
                } else {
                    $scope.newTableObj.enableActive = true;
                }
                vm.masterItemId = getMasterId(vm.masterTable.code);
                if (vm.actualSelectedRow.modifiedBy.userId === null) {
                    $scope.newTableObj.modifiedBy = vm.loggedInUser;
                }
                vm.displayMaster = angular.copy($scope.newTableObj);
            }
        }

        function deleteMasterData() {
            $scope.newTableObj = vm.selectedRow;
            vm.masterItemId = getMasterId(vm.masterTable.code);
            if (angular.isUndefined(vm.selectedRow.active)) {
                growlService.growl(messages.common.deleteMasterFields, 'danger');
            } else {
                swal({
                    title: messages.common.deleteAlertMessage1 + vm.masterTable.displayName + messages.common.deleteAlertMessage2,
                    type: "warning",
                    confirmButtonColor: "#3085d6",
                    confirmButtonText: "DELETE",
                    showCancelButton: true,
                    closeOnConfirm: true
                }, function () {
                    // });
                    masterService.delete({
                        masterTypeName: vm.masterTable.code,
                        masterItemId: vm.masterItemId
                    }, $scope.newTableObj,
                            function (response) {
                                vm.masterDel = response;
                                growlService.growl(messages.admin.adminRejectSuccessful, 'success');
                                var masterName = getMasterName(vm.masterTable.code);//To get master code for specific transaction like ata -ataCode, enginetype -engineTypeId
                                var masterId = getMasterId(vm.masterTable.code);//To get the value of selected row based on transaction
                                if (response) {
                                    for (var i = 0; i < vm.master.length; i++) {
                                        if (vm.master[i][masterName] === masterId) {
                                            vm.master.splice(i, 1);
                                            vm.masterTableParams.page(1);
                                            vm.selectedRow = {};
                                            vm.masterTableParams.reload();
                                            vm.masterTableParams.page();
                                            break;
                                        }
                                    }
                                }
                                vm.isEditing = false;
                            },
                            function (error) {
                                growlService.growl(error.data.message, 'danger');
                            }
                    );
                    //To reset the isEdit value inorder to enable only the selected row
                    angular.forEach(vm.master, function (value, key) {
                        if (value.isEdit !== undefined && value.isEdit) {
                            value.isEdit = false;
                        }
                    });
                });
            }
        }

        function saveMasterData() {
            if (vm.isEdit === false) {
                if (validateMasters()) {
                    masterService.add({
                        masterTypeName: vm.masterTable.code
                    }, $scope.newTableObj,
                            function (response) {
                                vm.masterNew = response;
                                growlService.growl(messages.admin.adminSaveSuccessful, 'success');
                                vm.master.splice(0, 1);
                                vm.master.splice(0, 0, vm.masterNew);
                                initializeMaster(vm.master);
                                vm.isEditing = false;
                                vm.isCreate = false;
                                vm.isEdit = false;
                                vm.isRejected = true;
                                vm.form.$submitted = true;
                                vm.enbaleSelectRow = false;
                                vm.form.$dirty = false;

                            },
                            function (error) {
                                growlService.growl(error.data.message, 'danger');
                                vm.masterTableParams.reload();
                                vm.enbaleSelectRow = false;
                            }
                    );
                    angular.forEach(vm.master, function (value, key) {
                        if (value.isEdit !== undefined && value.isEdit) {
                            value.isEdit = false;
                        }
                    });
                }
            } else {
                if (validateMasters()) {
                    masterService.update({
                        masterTypeName: vm.masterTable.code,
                        masterItemId: vm.masterItemId
                    }, $scope.newTableObj,
                            function (response) {
                                vm.masterUpdate = response;
                                growlService.growl(messages.admin.adminUpdateSuccessful, 'success');
                                var masterName = getMasterName(vm.masterTable.code);
                                var masterId = getMasterId(vm.masterTable.code);
                                for (var i = 0; i < vm.master.length; i++) {
                                    if (vm.master[i][masterName] === masterId) {
                                        vm.master.splice(i, 1, vm.masterUpdate);
                                        vm.masterTableParams.page(1);
                                        vm.selectedRow = {};
                                        vm.masterTableParams.reload();
                                        vm.masterTableParams.page();
                                        break;
                                    }
                                }
                                vm.isEditing = false;
                                vm.isCreate = false;
                                vm.isRejected = true;
                                vm.form.$submitted = true;
                                vm.enbaleSelectRow = false;
                                vm.form.$dirty = false;
                            },
                            function (error) {
                                growlService.growl(error.data.message, 'danger');
                                vm.enbaleSelectRow = false;
                            }

                    );
                    angular.forEach(vm.master, function (value, key) {
                        if (value.isEdit !== undefined && value.isEdit) {
                            value.isEdit = false;
                        }
                    });
                }
            }
        }
        function cancelChanges() {
            vm.isEditing = false;
            vm.isCreate = false;
            vm.isRejected = true;
            vm.form.$submitted = true;
            vm.form.$invalid = false;
            vm.enableIsActive = true;
            vm.enbaleSelectRow = false;
            if (vm.isEdit === false) { //add
                vm.master.splice(0, 1);
                vm.masterTableParams.page(1);
                vm.masterTableParams.reload();
                var currentPage = vm.masterTableParams.page();
                vm.masterTableParams.page(currentPage);
            } else {//update
                if (vm.masterTable.code === masterTypeConstants.REJECTION_CODE) {
                    angular.forEach(vm.master, function (value, key) {
                        if (value.managerItems.length !== vm.displayMaster.managerItems.length) {
                            value.managerItems = angular.copy(vm.displayMaster.managerItems);
                        }
                    });
                }
                angular.forEach(vm.master, function (value, key) {
                    if (value.isEdit !== undefined && value.isEdit) {
                        value.isEdit = false;
                    }
                    vm.selectedRow = {};
                });
                vm.master.splice(0, 0);
                vm.masterTableParams.page(1);
                vm.masterTableParams.reload();
                var currentPage = vm.masterTableParams.page();
                vm.masterTableParams.page(currentPage);
            }
            initializeMaster(vm.master);
        }


        function selectRow(row) {
            if (vm.selectedRow !== 0) {
                vm.actualSelectedRow = row;
                row.isEdit = true;
                vm.enableIsActive = false;
            } else {
                vm.actualSelectedRow = 0;
                row.isEdit = false;
                vm.enableIsActive = true;
            }
        }

        function createNewObj(type) {
            var newObj = {};
            switch (type) {
                case masterTypeConstants.ATA:
                    newObj = {
                        "isNew": true,
                        "ataCode": null,
                        "ataTitle": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.ENGINE_TYPE:
                    newObj = {
                        "isNew": true,
                        "engineType": null,
                        "engineName": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.TAG_NAMES:
                    newObj = {
                        "isNew": true,
                        "tagName": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.SNS_ACTION:
                    newObj = {
                        "isNew": true,
                        "actionCode": null,
                        "actionDesc": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.REQUEST_STATUS:
                    newObj = {
                        "isNew": true,
                        "statusCode": null,
                        "statusName": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.MATERIAL_TYPES:
                    newObj = {
                        "isNew": true,
                        "materialTypeCode": null,
                        "materialTypeName": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.MATERIAL_CODES:
                    newObj = {
                        "isNew": true,
                        "materialCode": null,
                        "materialCodeDes": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.MANAGER_ITEMS:
                    newObj = {
                        "isNew": true,
                        "managerItemCode": null,
                        "managerItemName": null,
                        "needByDaysOfGrace": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.LEAD_GROUPS:
                    newObj = {
                        "isNew": true,
                        "leadGroup": null,
                        "leadGroupName": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.ENGINE_MANUFACTURERS:
                    newObj = {
                        "isNew": true,
                        "engineManufacturerCode": null,
                        "engineManufacturerDesc": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.PREFIX:
                    newObj = {
                        "isNew": true,
                        "prefixCode": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.DISASSEMBLY_PREFIX:
                    newObj = {
                        "isNew": true,
                        "prefixCode": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.DISASSEMBLY_DC_ACTION:
                    newObj = {
                        "isNew": true,
                        "actionCode": null,
                        "actionDescription": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.DISASSEMBLY_VC_ACTION:
                    newObj = {
                        "isNew": true,
                        "actionCode": null,
                        "actionDescription": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.INFOCODE_ACTION:
                    newObj = {
                        "isNew": true,
                        "actionCode": null,
                        "actionDescription": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.REQUEST_TAGNAME:
                    newObj = {
                        "isNew": true,
                        "requestTagName": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.AIRPLANE_MODEL_TYPE:
                    newObj = {
                        "isNew": true,
                        "airplaneModel": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.DOC_TYPE:
                    newObj = {
                        "isNew": true,
                        "docTypeName": null,
                        "docTypeDescription": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                case masterTypeConstants.REJECTION_CODE:
                    newObj = {
                        "isNew": true,
                        "rejectionId": null,
                        "rejectionCodeDesc": null,
                        "active": true,
                        "enableActive": false
                    };
                    break;
                default:
            }
            return newObj;
        }

        //To get the Master name to handle the logic in delete and update function
        function getMasterName(masterName) {
            var masterItemId = null;
            switch (masterName) {
                case masterTypeConstants.ATA:
                    masterItemId = masterTypeConstants.ATA_CODE;
                    break;
                case masterTypeConstants.ENGINE_TYPE:
                    masterItemId = masterTypeConstants.ENGINE_TYPE_ID;
                    break;
                case masterTypeConstants.TAG_NAMES:
                    masterItemId = masterTypeConstants.TAG_NAME_ID;
                    break;
                case masterTypeConstants.SNS_ACTION:
                    masterItemId = masterTypeConstants.SNS_ACTION_ID;
                    break;
                case masterTypeConstants.REQUEST_STATUS:
                    masterItemId = masterTypeConstants.REQUEST_STATUS_ID;
                    break;
                case masterTypeConstants.MATERIAL_TYPES:
                    masterItemId = masterTypeConstants.MATERIAL_TYPE_ID;
                    break;
                case masterTypeConstants.MATERIAL_CODES:
                    masterItemId = masterTypeConstants.MATERIAL_CODE_ID;
                    break;
                case masterTypeConstants.MANAGER_ITEMS:
                    masterItemId = masterTypeConstants.MANAGER_ITEM_ID;
                    break;
                case masterTypeConstants.LEAD_GROUPS:
                    masterItemId = masterTypeConstants.LEAD_GROUP_ID;
                    break;
                case masterTypeConstants.ENGINE_MANUFACTURERS:
                    masterItemId = masterTypeConstants.ENGINE_MANUFACTURER_ID;
                    break;
                case masterTypeConstants.PREFIX:
                    masterItemId = masterTypeConstants.PREFIX_ID;
                    break;
                case masterTypeConstants.DISASSEMBLY_PREFIX:
                    masterItemId = masterTypeConstants.DISASSEMBLY_PREFIX_ID;
                    break;
                case masterTypeConstants.TOOLTAG_TYPE:
                    masterItemId = masterTypeConstants.TOOLTAG_TYPE_ID;
                    break;
                case masterTypeConstants.DISASSEMBLY_DC_ACTION:
                    masterItemId = masterTypeConstants.DISASSEMBLY_DC_ACTION_ID;
                    break;
                case masterTypeConstants.DISASSEMBLY_VC_ACTION:
                    masterItemId = masterTypeConstants.DISASSEMBLY_VC_ACTION_ID;
                    break;
                case masterTypeConstants.INFOCODE_ACTION:
                    masterItemId = masterTypeConstants.INFOCODE_ACTION_ID;
                    break;
                case masterTypeConstants.REQUEST_TAGNAME:
                    masterItemId = masterTypeConstants.REQUEST_TAGNAME_ID;
                    break;
                case masterTypeConstants.AIRPLANE_MODEL_TYPE:
                    masterItemId = masterTypeConstants.AIRPLANE_MODEL_ID;
                    break;
                case masterTypeConstants.DOC_TYPE:
                    masterItemId = masterTypeConstants.DOC_TYPE_ID;
                    break;
                case masterTypeConstants.REJECTION_CODE:
                    masterItemId = masterTypeConstants.REJECTION_ID;
                    break;
                default:
            }
            return masterItemId;
        }



        //To pass the one of the parameter for update and delete service
        function getMasterId(masterName) {
            var masterItemId = null;
            switch (masterName) {
                case masterTypeConstants.ATA:
                    masterItemId = vm.selectedRow.ataId;
                    break;
                case masterTypeConstants.ENGINE_TYPE:
                    masterItemId = vm.selectedRow.engineTypeId;
                    break;
                case masterTypeConstants.TAG_NAMES:
                    masterItemId = vm.selectedRow.tagNameId;
                    break;
                case masterTypeConstants.SNS_ACTION:
                    masterItemId = vm.selectedRow.actionId;
                    break;
                case masterTypeConstants.REQUEST_STATUS:
                    masterItemId = vm.selectedRow.statusId;
                    break;
                case masterTypeConstants.MATERIAL_TYPES:
                    masterItemId = vm.selectedRow.materialTypeId;
                    break;
                case masterTypeConstants.MATERIAL_CODES:
                    masterItemId = vm.selectedRow.materialCodeId;
                    break;
                case masterTypeConstants.MANAGER_ITEMS:
                    masterItemId = vm.selectedRow.managerItemId;
                    break;
                case masterTypeConstants.LEAD_GROUPS:
                    masterItemId = vm.selectedRow.leadGroupid;
                    break;
                case masterTypeConstants.ENGINE_MANUFACTURERS:
                    masterItemId = vm.selectedRow.engineManufacturerId;
                    break;
                case masterTypeConstants.PREFIX:
                    masterItemId = vm.selectedRow.prefixId;
                    break;
                case masterTypeConstants.DISASSEMBLY_PREFIX:
                    masterItemId = vm.selectedRow.prefixId;
                    break;
                case masterTypeConstants.DISASSEMBLY_DC_ACTION:
                    masterItemId = vm.selectedRow.actionId;
                    break;
                case masterTypeConstants.DISASSEMBLY_VC_ACTION:
                    masterItemId = vm.selectedRow.actionId;
                    break;
                case masterTypeConstants.INFOCODE_ACTION:
                    masterItemId = vm.selectedRow.actionId;
                    break;
                case masterTypeConstants.REQUEST_TAGNAME:
                    masterItemId = vm.selectedRow.requestTagNameId;
                    break;
                case masterTypeConstants.AIRPLANE_MODEL_TYPE:
                    masterItemId = vm.selectedRow.airplaneModelId;
                    break;
                case masterTypeConstants.DOC_TYPE:
                    masterItemId = vm.selectedRow.docTypeId;
                    break;
                case masterTypeConstants.REJECTION_CODE:
                    masterItemId = vm.selectedRow.rejectionId;
                    break;

                default:
            }
            return masterItemId;
        }

        //displaying grid data
        function initializeMaster(data) {
            switch (vm.masterTable.code) {
                case masterTypeConstants.ATA:
                    initializeATATable(data);
                    break;
                case masterTypeConstants.ENGINE_TYPE:
                    initializeEngineType(data);
                    break;
                case masterTypeConstants.TAG_NAMES:
                    initializeTagNameTable(data);
                    break;
                case masterTypeConstants.SNS_ACTION:
                    initializeSNSActionTable(data);
                    break;
                case masterTypeConstants.REQUEST_STATUS:
                    initializeRequestStatusTable(data);
                    break;
                case masterTypeConstants.MATERIAL_TYPES:
                    initializeMaterialTypeTable(data);
                    break;
                case masterTypeConstants.MATERIAL_CODES:
                    initializeMaterialCodesTable(data);
                    break;
                case masterTypeConstants.MANAGER_ITEMS:
                    initializeManagerItemsTable(data);
                    break;
                case masterTypeConstants.LEAD_GROUPS:
                    initializeLeadGroupsTable(data);
                    break;
                case masterTypeConstants.ENGINE_MANUFACTURERS:
                    initializeEngineManufacturerTable(data);
                    break;
                case masterTypeConstants.PREFIX:
                    initializePrefixTable(data);
                    break;
                case masterTypeConstants.DISASSEMBLY_PREFIX:
                    initializeDisassemblyPrefixTable(data);
                    break;
                case masterTypeConstants.DISASSEMBLY_DC_ACTION:
                    initializeDisAssemDCActionTable(data);
                    break;
                case masterTypeConstants.DISASSEMBLY_VC_ACTION:
                    initializeDisAssemVCActionTable(data);
                    break;
                case masterTypeConstants.INFOCODE_ACTION:
                    initializeInfocodeActionTable(data);
                    break;
                case masterTypeConstants.REQUEST_TAGNAME:
                    initializeRequestTagNameTable(data);
                    break;
                case masterTypeConstants.AIRPLANE_MODEL_TYPE:
                    initializeAirplaneModelTable(data);
                    break;
                case masterTypeConstants.DOC_TYPE:
                    initializeDocTypeTable(data);
                    break;
                case masterTypeConstants.REJECTION_CODE:
                    initializeRejectionCodeTable(data);
                    break;
                default:
            }
        }

        //ATA
        function initializeATATable(data) {
            if (data !== undefined) {
                for (var i = 0; i < data.length; i++) {
                    data[i].strModifiedOn = $filter('date')(data[i].modifiedOn, "dd-MMM-yyyy");
                }
            }
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "ataChapter", valueExpr: "item.ataChapter", title: "ATA CHAPTER", filter: {"ataChapter": "text"}, sortable: "ataChapter", maxLength: fieldLengthConstants.ATA_CHAPTER},
                {type: "text", field: "ataCode", valueExpr: "item.ataCode", title: "ATA TITLE", filter: {"ataCode": "text"}, sortable: "ataCode", maxLength: fieldLengthConstants.ATA_CODE},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"strModifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}
            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //ENGINE TYPE
        function initializeEngineType(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "engineType", valueExpr: "item.engineType", title: "ENGINE TYPE", filter: {"engineType": "text"}, sortable: "engineType", maxLength: fieldLengthConstants.ENGINE_TYPE},
                {type: "text", field: "engineName", valueExpr: "item.engineName", title: "ENGINE NAME", filter: {"engineName": "text"}, sortable: "engineName", maxLength: fieldLengthConstants.ENGINE_NAME},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}
            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //TAG NAME
        function initializeTagNameTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "tagName", valueExpr: "item.tagName", title: "TAG NAME", filter: {"tagName": "text"}, sortable: "tagName", maxLength: fieldLengthConstants.TAG_NAME},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}
            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //SNS ACTION
        function initializeSNSActionTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "actionCode", valueExpr: "item.actionCode", title: "ACTION CODE", filter: {"actionCode": "text"}, sortable: "actionCode", maxLength: fieldLengthConstants.ACTION_CODE},
                {type: "text", field: "actionDesc", valueExpr: "item.actionDesc", title: "ACTION DESCRIPTION", filter: {"actionDesc": "text"}, sortable: "actionDesc", maxLength: fieldLengthConstants.ACTION_DESCRIPTION},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}
            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //REQUEST STATUS
        function initializeRequestStatusTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "statusCode", valueExpr: "item.statusCode", title: "STATUS CODE", filter: {"statusCode": "text"}, sortable: "statusCode", maxLength: fieldLengthConstants.STATUS_CODE},
                {type: "text", field: "statusName", valueExpr: "item.statusName", title: "STATUS NAME", filter: {"statusName": "text"}, sortable: "statusName", maxLength: fieldLengthConstants.STATUS_NAME},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //MATERIAL TYPES
        function initializeMaterialTypeTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "materialTypeCode", valueExpr: "item.materialTypeCode", title: "MATERIAL TYPE ID", filter: {"materialTypeCode": "text"}, sortable: "materialTypeCode", maxLength: fieldLengthConstants.MATERIAL_TYPE_CODE},
                {type: "text", field: "materialTypeName", valueExpr: "item.materialTypeName", title: "MATERIAL TYPE NAME", filter: {"materialTypeName": "text"}, sortable: "materialTypeName", maxLength: fieldLengthConstants.MATERIAL_TYPE_NAME},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn| date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}


            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //MATERIAL CODES
        function initializeMaterialCodesTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "materialCode", valueExpr: "item.materialCode", title: "MATERIAL CODE", filter: {"materialCode": "text"}, sortable: "materialCode", maxLength: fieldLengthConstants.MATERIAL_CODE},
                {type: "text", field: "materialCodeDes", valueExpr: "item.materialCodeDes", title: "MATERIAL DESCRIPTION", filter: {"materialCodeDes": "text"}, sortable: "materialCodeDes", maxLength: fieldLengthConstants.MATERIAL_CODE_DESC},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //MANAGERITEMS
        function initializeManagerItemsTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "managerItemCode", valueExpr: "item.managerItemCode", title: "MANAGER ITEM ID", filter: {"managerItemId": "text"}, sortable: "managerItemId", maxLength: fieldLengthConstants.MATERIAL_ITEM_CODE},
                {type: "text", field: "managerItemName", valueExpr: "item.managerItemName", title: "MANAGER ITEM NAME", filter: {"managerItemName": "text"}, sortable: "managerItemName", maxLength: fieldLengthConstants.MATERIAL_ITEM_NAME},
                {type: "text", field: "needByDaysOfGrace", valueExpr: "item.needByDaysOfGrace", title: "NEED BY DAYS OF GRACE", filter: {"needBydaysOfgrace": "text"}, sortable: "needBydaysOfgrace", maxLength: fieldLengthConstants.NEED_BY_DAYS_OF_GRACE},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy": "text"}, sortable: "modifiedBy"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //LEAD GROUP
        function initializeLeadGroupsTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "leadGroup", valueExpr: "item.leadGroup", title: "LEAD GROUP", filter: {"leadGroup": "text"}, sortable: "leadGroup", maxLength: fieldLengthConstants.LEAD_GROUP},
                {type: "text", field: "leadGroupName", valueExpr: "item.leadGroupName", title: "LEAD GROUP NAME", filter: {"leadGroupName": "text"}, sortable: "leadGroupName", maxLength: fieldLengthConstants.LEAD_GROUP_NAME},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //ENGINE MANUFACTURER
        function initializeEngineManufacturerTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", valueExpr: "item.selectedRow", title: "SELECT"},
                {type: "text", field: "engineManufacturerCode", valueExpr: "item.engineManufacturerCode", title: "ENGINE MANUFACTURER CODE", filter: {"engineManufacturerCode": "text"}, sortable: "engineManufacturerCode", maxLength: fieldLengthConstants.ENGINE_MANUFACTURER_CODE},
                {type: "text", field: "engineManufacturerDesc", valueExpr: "item.engineManufacturerDesc", title: "ENGINE MANUFACTURER DESCRIPTION", filter: {"engineManufacturerDesc": "text"}, sortable: "engineManufacturerDesc", maxLength: fieldLengthConstants.ENGINE_MANUFACTURER_DESC},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //PREFIX
        function initializePrefixTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "prefixCode", valueExpr: "item.prefixCode", title: "PREFIX CODE", filter: {"prefixCode": "text"}, sortable: "prefixCode", maxLength: fieldLengthConstants.PREFIX_CODE},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}


            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //DISASSEMBLY PREFIX
        function initializeDisassemblyPrefixTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "prefixCode", valueExpr: "item.prefixCode", title: "PREFIX CODE", filter: {"prefixCode": "text"}, sortable: "prefixCode", maxLength: fieldLengthConstants.DISASSEMBLY_PREFIX_CODE},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}


            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }



        //REQUEST TAG NAME
        function initializeRequestTagNameTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "requestTagName", valueExpr: "item.requestTagName", title: "REQUEST TAG NAME", filter: {"requestTagName": "text"}, sortable: "requestTagName", maxLength: fieldLengthConstants.REQUEST_TAG_NAME},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isISActive", title: "ACTIVE", sortable: "isActive"}


            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //DISASSEMBLY DC ACTION
        function initializeDisAssemDCActionTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "actionCode", valueExpr: "item.actionCode", title: "ACTION CODE", filter: {"actionCode": "text"}, sortable: "actionCode", maxLength: fieldLengthConstants.ACTION_CODE},
                {type: "text", field: "actionDescription", valueExpr: "item.actionDescription", title: "ACTION DESCRIPTION", filter: {"actionDescription": "text"}, sortable: "actionDescription", maxLength: fieldLengthConstants.ACTION_DESCRIPTION},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}


            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //DISASSEMBLY VC ACTION
        function initializeDisAssemVCActionTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "actionCode", valueExpr: "item.actionCode", title: "ACTION CODE", filter: {"actionCode": "text"}, sortable: "actionCode", maxLength: fieldLengthConstants.ACTION_CODE},
                {type: "text", field: "actionDescription", valueExpr: "item.actionDescription", title: "ACTION DESCRIPTION", filter: {"actionDescription": "text"}, sortable: "actionDescription", maxLength: fieldLengthConstants.ACTION_DESCRIPTION},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}


            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //INFOCODE ACTION
        function initializeInfocodeActionTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "actionCode", valueExpr: "item.actionCode", title: "ACTION CODE", filter: {"actionCode": "text"}, sortable: "actionCode", maxLength: fieldLengthConstants.INFOCODE_ACTION_CODE},
                {type: "text", field: "actionDescription", valueExpr: "item.actionDescription", title: "ACTION DESCRIPTION", filter: {"actionDescription": "text"}, sortable: "actionDescription", maxLength: fieldLengthConstants.ACTION_DESCRIPTION},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}
            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //DOC TYPE
        function initializeDocTypeTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "docTypeName", valueExpr: "item.docTypeName", title: "DOCTYPE NAME", filter: {"docTypeName": "text"}, sortable: "docTypeName", maxLength: fieldLengthConstants.DOC_TYPE_NAME},
                {type: "text", field: "docTypeDescription", valueExpr: "item.docTypeDescription", title: "DOC TYPE DESCRIPTION", filter: {"docTypeDescription": "text"}, sortable: "docTypeDescription", maxLength: fieldLengthConstants.DOC_TYPE_DESC},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy.fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //AIRPLANE MODEL
        function initializeAirplaneModelTable(data) {
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "airplaneModel", valueExpr: "item.airplaneModel", title: "AIRPLANE MODEL", filter: {"airplaneModel": "text"}, sortable: "airplaneModel", maxLength: fieldLengthConstants.AIRPLANE_MODEL},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"modifiedOn": "text"}, sortable: "modifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "fullName"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        //REJECTION CODE
        function initializeRejectionCodeTable(data) {
            if (data !== undefined) {
                for (var i = 0; i < data.length; i++) {
                    data[i].strModifiedOn = $filter('date')(data[i].modifiedOn, "dd-MMM-yyyy");
                }
            }
            vm.isdisplayRejection = true;
            vm.masterTableParams = {};
            vm.masterTableColumns = [
                {type: "selector", field: "selector", title: "SELECT"},
                {type: "text", field: "rejectionCodeDesc", valueExpr: "item.rejectionCodeDesc", title: "REJECTION CODE DESCRIPTION", filter: {"rejectionCodeDesc": "text"}, sortable: "rejectionCodeDesc", maxLength: fieldLengthConstants.REJECTION_CODE_DESC},
                {type: "dropdown", field: "managerItems", valueExpr: "item.managerItems.managerItemName", title: "MANAGER ITEMS", filter: {"managerItems.managerItemName": "text"}, sortable: "managerItems.managerItemName"},
                {type: "label", field: "modifiedOn", valueExpr: "item.modifiedOn | date:'dd-MMM-yyyy'", title: "MODIFIED ON", filter: {"strModifiedOn": "text"}, sortable: "strModifiedOn"},
                {type: "label", field: "modifiedBy", valueExpr: "item.modifiedBy.fullName", title: "MODIFIED BY", filter: {"modifiedBy.fullName": "text"}, sortable: "modifiedBy"},
                {type: "checkbox", field: "active", valueExpr: "item.isActive", title: "ACTIVE", sortable: "isActive"}

            ];
            vm.masterTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        dataset: data
                    });
        }

        function setDefaultManagerItems() {
            angular.forEach(vm.master, function (value, key) {
                if (!vm.iterate) {
                    vm.managerOptions = value.managerItems;
                    vm.iterate = true;
                }
            });
        }

        function validateMasters() {
            if (angular.isDefined($scope.newTableObj)) {
                switch (vm.masterTable.code) {
                    case masterTypeConstants.ATA:
                        if (($scope.newTableObj.ataChapter === null) || ($scope.newTableObj.ataCode === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.ataChapter.length <= fieldLengthConstants.ATA_CHAPTER) && ($scope.newTableObj.ataCode.length <= fieldLengthConstants.ATA_CODE)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.ENGINE_TYPE:
                        if (($scope.newTableObj.engineType === null) || ($scope.newTableObj.engineName === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.engineType.length <= fieldLengthConstants.ENGINE_TYPE) && ($scope.newTableObj.engineName.length <= fieldLengthConstants.ENGINE_NAME)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.TAG_NAMES:
                        if (($scope.newTableObj.tagName === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.tagName.length <= fieldLengthConstants.TAG_NAME)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.SNS_ACTION:
                        if (($scope.newTableObj.actionCode === null) || ($scope.newTableObj.actionDesc === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.actionCode.length <= fieldLengthConstants.ACTION_CODE) && ($scope.newTableObj.actionDesc.length <= fieldLengthConstants.ACTION_DESCRIPTION)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.REQUEST_STATUS:
                        if (($scope.newTableObj.statusCode === null) || ($scope.newTableObj.statusName === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.statusCode.length <= fieldLengthConstants.STATUS_CODE) && ($scope.newTableObj.statusName.length <= fieldLengthConstants.STATUS_NAME)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.MATERIAL_TYPES:
                        if (($scope.newTableObj.materialTypeCode === null) || ($scope.newTableObj.materialTypeName === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.materialTypeCode.length <= fieldLengthConstants.MATERIAL_TYPE_CODE) && ($scope.newTableObj.materialTypeName.length <= fieldLengthConstants.MATERIAL_TYPE_NAME)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.MATERIAL_CODES:
                        if (($scope.newTableObj.materialCode === null) || ($scope.newTableObj.materialCodeDes === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.materialCode.length <= fieldLengthConstants.MATERIAL_CODE) && ($scope.newTableObj.materialCodeDes.length <= fieldLengthConstants.MATERIAL_CODE_DESC)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.MANAGER_ITEMS:
                        if (($scope.newTableObj.managerItemCode === null) || ($scope.newTableObj.managerItemName === null) || ($scope.newTableObj.needByDaysOfGrace === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.managerItemCode.length <= fieldLengthConstants.MATERIAL_ITEM_CODE) && ($scope.newTableObj.managerItemName.length <= fieldLengthConstants.MATERIAL_ITEM_NAME) && ($scope.newTableObj.needByDaysOfGrace.toString().length <= fieldLengthConstants.NEED_BY_DAYS_OF_GRACE)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.LEAD_GROUPS:
                        if (($scope.newTableObj.leadGroup === null) || ($scope.newTableObj.leadGroupName === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.leadGroup.length <= fieldLengthConstants.LEAD_GROUP) && ($scope.newTableObj.leadGroupName.length <= fieldLengthConstants.LEAD_GROUP_NAME)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.ENGINE_MANUFACTURERS:
                        if (($scope.newTableObj.engineManufacturerCode === null) || ($scope.newTableObj.engineManufacturerDesc === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.engineManufacturerCode.length <= fieldLengthConstants.ENGINE_MANUFACTURER_CODE) && ($scope.newTableObj.engineManufacturerDesc.length <= fieldLengthConstants.ENGINE_MANUFACTURER_DESC)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.PREFIX:
                        if (($scope.newTableObj.prefixCode === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.prefixCode.length <= fieldLengthConstants.PREFIX_CODE)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.DISASSEMBLY_PREFIX:
                        if (($scope.newTableObj.prefixCode === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.prefixCode.length <= fieldLengthConstants.DISASSEMBLY_PREFIX_CODE)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.DISASSEMBLY_DC_ACTION:
                        if (($scope.newTableObj.actionCode === null) || ($scope.newTableObj.actionDescription === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.actionCode.length <= fieldLengthConstants.ACTION_CODE) && ($scope.newTableObj.actionDescription.length <= fieldLengthConstants.ACTION_DESCRIPTION)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.DISASSEMBLY_VC_ACTION:
                        if (($scope.newTableObj.actionCode === null) || ($scope.newTableObj.actionDescription === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.actionCode.length <= fieldLengthConstants.ACTION_CODE) && ($scope.newTableObj.actionDescription.length <= fieldLengthConstants.ACTION_DESCRIPTION)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.INFOCODE_ACTION:
                        if (($scope.newTableObj.actionCode === null) || ($scope.newTableObj.actionDescription === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.actionCode.length <= fieldLengthConstants.INFOCODE_ACTION_CODE) && ($scope.newTableObj.actionDescription.length <= fieldLengthConstants.ACTION_DESCRIPTION)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.REQUEST_TAGNAME:
                        if ($scope.newTableObj.requestTagName === null) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if ($scope.newTableObj.requestTagName.length <= fieldLengthConstants.REQUEST_TAG_NAME) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.AIRPLANE_MODEL_TYPE:
                        if ($scope.newTableObj.airplaneModel === null) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if ($scope.newTableObj.airplaneModel.length <= fieldLengthConstants.AIRPLANE_MODEL) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.DOC_TYPE:
                        if (($scope.newTableObj.docTypeName === null) || ($scope.newTableObj.docTypeDescription === null)) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.docTypeName.length <= fieldLengthConstants.DOC_TYPE_NAME) && ($scope.newTableObj.docTypeDescription.length <= fieldLengthConstants.DOC_TYPE_DESC)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    case masterTypeConstants.REJECTION_CODE:
                        if (($scope.newTableObj.rejectionCodeDesc === null) || (angular.isUndefined($scope.newTableObj.managerItems))) {
                            growlService.growl(messages.common.enterMandatoryFields, 'danger');
                            return false;
                        } else {
                            if (($scope.newTableObj.rejectionCodeDesc.length <= fieldLengthConstants.REJECTION_CODE_DESC)) {
                                return true;
                            } else {
                                growlService.growl(messages.common.invalidFieldLength, 'danger');
                                return false;
                            }
                        }
                        break;
                    default:
                }
            } else {
            }
        }
    }
})();

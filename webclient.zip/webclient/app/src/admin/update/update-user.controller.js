(function () {
    'use strict';
    angular.module('gsesp.admin.search')
            .controller('AdminUpdateController', AdminUpdateController);
    AdminUpdateController.$inject = ['adminDataService', '$stateParams', 'growlService', 'messages', 'layoutService', '$state', 'authService', '$rootScope', 'userRole', 'requestName'];
    function AdminUpdateController(adminDataService, $stateParams, growlService, messages, layoutService, $state, authService, $rootScope, userRole, requestName) {
        var vm = this;
        vm.layout = layoutService;
        vm.requestTypes = [];
        vm.reponsibleGroups = [];
        vm.isManager = false;
                
        initialize();
        vm.assign = assign;
        vm.cancel = cancel;
        function initialize() {
            getUserForBemsId($stateParams.bemsId);
            getReponsibleGroups();
        }
        vm.cardSections = {
            addUser: {id: "addUser", title: "Add/Update", isCollapsed: false},
            managerAssignments: {id: "managerAssignments", title: "Manager Assignments", isCollapsed: true}
        };

        function getReponsibleGroups() {
            adminDataService.getReponsibleGroups().then(function (response) {
                vm.leadGroupsList = response;
            });
        }
        function getUserForBemsId(bemsId) {
            adminDataService.getUserForBemsId(bemsId).then(function (response) {
                vm.userDetails = response.userVO;
                vm.requestTypes = response.managerVOs;
                vm.managerLeadGroup = [];
                angular.forEach(response.managerLeadGroupVOs, function (value, key) {
                    vm.managerLeadGroup[key] = value.leadGroupsDetials;
                });
            });
        }

        function assign(data) {

            var userVO = {bemsId: vm.userDetails.bemsId, isActive: vm.userDetails.isActive, userRoleVO: vm.userDetails.userRoleVO, userId: vm.userDetails.userId};
            var increment = 0;
            var managerVOs = [];
            var leadGroupVOs = [];
            var flag = false;
            var isLeadGroup = false;
            angular.forEach(data, function (value, key) {
                if (value.userDetails.userId !== 0 && value.userDetails.userId !== null) {
                    if (value.managerItemDetails.managerItemName === requestName.TOOLS) {
                        managerVOs[increment++] = value;
                        if (vm.managerLeadGroup.length === 0) {
                            isLeadGroup = true;
                        } else {
                            leadGroupVOs = vm.managerLeadGroup;
                        }

                    } else {
                        managerVOs[increment++] = value;
                    }
                } else {
                    if (value.managerItemDetails.managerItemName === requestName.TOOLS) {
                        if ((value.userDetails.userId === null || value.userDetails.userId === 0) && (value.lmContact === true || value.recieveEmail === true || (value.specialty !== null && value.specialty !== "") || vm.managerLeadGroup.length > 0)) {
                            flag = true;
                        }
                    } else {
                        if ((value.userDetails.userId === null || value.userDetails.userId === 0) && (value.lmContact === true || value.recieveEmail === true || (value.specialty !== null && value.specialty !== ""))) {
                            flag = true;
                        }
                    }
                }
            });

            var managerUpdate = {userVO: userVO, managerVOs: managerVOs, leadGroupVOs: leadGroupVOs};
            if (!flag && !isLeadGroup) {
                adminDataService.updateManagerDetials(managerUpdate).then(function (response) {
                    vm.isSuccess = response;
                    var currentUser = authService.getUser();
                    if (currentUser.bemsId === vm.userDetails.bemsId) {

                        authService.updateLoggedInUser(vm.userDetails);
                        if (vm.userDetails.userRoleVO && vm.userDetails.userRoleVO.roleId === userRole.ADMIN) {
                            //Stay in same page
                        } else {
                            //No point in keeping the user in Admin page. Hence redirecting to home page
                            $rootScope.$emit('updateSidebar');
                            $state.transitionTo('request', $stateParams, {reload: true, inherit: false});
                        }
                    }
                    if (vm.isSuccess) {
                        growlService.growl(messages.admin.userUpdated, 'success');
                    }
                }).catch(function (error) {
                    growlService.growl(error.data.message, 'danger');
                });
            } else {
                if (isLeadGroup) {
                    growlService.growl(messages.admin.needLeadGroups, 'danger');
                } else {
                    growlService.growl(messages.admin.needManager, 'danger');
                }
            }


        }
        
        
        function cancel() {
            if(vm.form.$dirty){
           swal({
                    title: messages.common.dirtyAlertTitleMessage,
                    text: messages.common.nonRecoverTextMessage,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Yes",
                    closeOnConfirm: true
                }, function () {                    
                    cancelConfirm();
                });
            
        }
        else
        {
            cancelConfirm();
        }
    }
        function cancelConfirm(){
            vm.userDetails = null;
            vm.requestTypes = null;
            vm.managerLeadGroup = null;
            if($state.includes('administration.assign')){
                $state.go('administration.addUser');
            }else{
                $state.go('administration.update');
        }
        }
    }
})();

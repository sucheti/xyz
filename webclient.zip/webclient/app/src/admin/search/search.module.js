(function () {
    'use strict';

    angular.module('gsesp.admin.search', [
        'ui.bootstrap'
    ]);
})();

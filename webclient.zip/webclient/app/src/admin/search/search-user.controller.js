(function () {
    'use strict';
    angular.module('gsesp.admin.search')
            .controller('AdminSearchTeamController', AdminSearchTeamController);

    AdminSearchTeamController.$inject = ['NgTableParams', 'adminDataService', 'layoutService','growlService','messages','$filter'];

    function AdminSearchTeamController(NgTableParams, adminDataService,layoutService, growlService, messages, $filter) {

        var vm = this;
        vm.layout = layoutService;
        vm.tableParams = {
            page: 1, // show first page
            count: 5 // count per page
        };

        vm.format = 'dd-MMM-yyyy';
        vm.queryUsers = queryUsers;
        vm.clearSearch = clearSearch;
        vm.openDatePicker = openDatePicker;
        vm.searchData = [];
        vm.query = {};
        vm.listManager = [];
        vm.dataLength = [];


        vm.isCollapsed = {
            searchResults: true,
            extraSearchFields: true
        };
        initialize();
        intiializeDatePickter();

        function initialize() {
            vm.query.active = false;
            vm.query.requester = 0;
            vm.query.admin = 0;
            vm.query.manager = false;
            getListManager();
        }
        function intiializeDatePickter() {
            // manages date picker open/close state
            vm.datePicker = {
                lastLogOnDate: false
            };

            
            vm.dateOptions = {
                formatYear: 'yy',
                minDate: new Date(),
                startingDay: 1
            };
            vm.dateOptions.minDate = vm.dateOptions.minDate ? null : new Date();
        }

        function openDatePicker($event, dateName) {
            $event.preventDefault();
            $event.stopPropagation();
            vm.datePicker[dateName] = true;
        }

        vm.cardSections = {
            existingUsers: {id: "assignRole", title: "Search GSESP User", isCollapsed: false}
        };

        function initializeAssignRoleTable(data) {
            angular.forEach(data, function (value,key){
                if(value !== undefined){
                    value.lastLogonDate = $filter('date')(value.lastLogonDate, "dd-MMM-yyyy");
                }
            });
            if (data !== undefined) {
                if (data.length >= 5 && data.length <= 10) {
                    vm.dataLength = [5, 10];
                } else if (data.length >= 11 && data.length <= 15) {
                    vm.dataLength = [5, 10, 15];
                } else if (data.length >= 16) {
                    vm.dataLength = [5, 10, 15, 20];
                } else {
                    vm.dataLength = [];
                }
            }
            vm.assignTableParams = {};
            vm.assignColumns = [
                {field: "bemsId", title: "BEMS ID", filter: {'bemsId': "text"}, sortable: "bemsId"},
                {valueExpr: "item.firstName", title: "FIRST NAME", filter: {'firstName': "text"}, sortable: "firstName"},
                {valueExpr: "item.middleInitial", title: "MIDDLE INITIAL", filter: {'middleInitial': "text"}, sortable: "middleInitial"},
                {valueExpr: "item.lastName", title: "LAST NAME", filter: {'lastName': "text"}, sortable: "lastName"},
                {valueExpr: "item.email", title: "EMAIL", filter: {'email': "text"}, sortable: "email"},
                {valueExpr: "item.lastLogonDate | date:'dd-MMM-yyyy'", title: "LAST LOGGED ON DATE", filter: {'lastLogonDate':"text"}, sortable: "lastLogonDate"},
                {field: "isActive", title: "Status", sortable: "isActive"}

            ];
            
            vm.assignTableParams = new NgTableParams(vm.tableParams,
                    {
                        counts: vm.dataLength,
                        dataset: data
                    });
        }

        function queryUsers(data) {
           vm.error = false;
            if (!isNaN(data.bemsId) || data.bemsId === undefined) {

                vm.isCollapsed.searchResults = false;
                adminDataService.searchGsepUsers(data).then(function (result) {
                initializeAssignRoleTable(result);
                vm.errorMessage = "";
            }).catch(function (error) {
                vm.errorMessage = error.data.message;
            });
            } else {
                growlService.growl(messages.searchBoeingUsers.bemsIdNumericErrorMessage, 'danger');
                vm.error = true;
            }
        }

        function getListManager() {
            adminDataService.getListManager().then(function (response) {
                vm.managerListItems = response;
            });
        }
        function clearSearch() {
            vm.isCollapsed.searchResults = true;
            vm.query.bemsId = null;
            vm.query.fullName = null;
            vm.query.listManager = null;
            vm.query.lastLogOnDate = null;
            vm.query.active = false;
            vm.query.isRequester = false;
            vm.query.isAdmin = false;
            vm.query.manager = false;
            vm.dataLength = [];
        }
    }
})();

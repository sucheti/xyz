(function (){
    'use strict';
    angular.module('gsesp')
            .constant('userRole',
                    {
                        ADMIN : 2,
                        REQUESTER : 1
                    })
            .constant('foreignPersonStatus',{
                FOREIGN_PERSON : 1,
                US_PERSON : 'N'
                    })
            .constant('userStatus',{
                ACTIVE : true,
                INACTIVE : false
                    })
             .constant('requestName',{
                TOOLS : "TOOLS"
                    })
            
})();

(function () {
    'use strict';

    angular
            .module('gsesp.admin')
            .run(appRun);

    appRun.$inject = ['routerHelper'];

    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [
            {
                state: 'administration',
                config: {
                    url: '/administration',
                    template: '<ui-view />',
                    redirectTo: 'administration.addUser',
                    resolve: {
                        loggedinUser: ['authService', '$window', function (authService, $window) {
                                // Return our Service call, that returns a Promise
                                return authService.getUserDetails().then(function (result) {
                                    // Do nothing
                                    return  result;
                                }).catch(function (error) {
                                    //Handle error
                                    $window.location.href = '/app/error.html';

                                });
                            }]
                    }
                }
            },
            {
                state: 'administration.addUser',
                config: {
                    url: '/add',
                    displayName: 'administration.add user',
                    templateUrl: 'src/admin/add-user/add-user.html',
                    controller: 'AdminAddController',
                    controllerAs: 'vm'
                }
            },
            {
                state: 'administration.update',
                config: {
                    url: '/update',
                    templateUrl: 'src/admin/search/search-user.html',
                    controller: 'AdminSearchTeamController',
                    controllerAs: 'vm'
                }
            },
            {
                state: 'administration.updateUser',
                config: {
                    url: '/update/:bemsId',
                    displayName: 'administration.update user',
                    templateUrl: 'src/admin/update/update-user.html',
                    controller: 'AdminUpdateController',
                    controllerAs: 'vm'
                }
            },
            {
                state: 'administration.assign',
                config: {
                    url: '/assign/:bemsId',
                    displayName: 'administration.update user',
                    templateUrl: 'src/admin/update/update-user.html',
                    controller: 'AdminUpdateController',
                    controllerAs: 'vm'
                }
            },
            {
                state: 'administration.update-master',
                config: {
                    url: '/update-master',
                    templateUrl: 'src/admin/update-master-data/update-master-data.html',
                    controller: 'AdminUpdateMasterController',
                    controllerAs: 'vm'
                }
            }

        ];
    }
})();





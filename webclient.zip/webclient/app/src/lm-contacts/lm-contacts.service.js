(function() {
    'use strict';
    
    angular
        .module('app.layout')
            .factory('lmContactsService', lmContactsService);
    lmContactsService.$inject = ['$http','apiHelper'];
    function lmContactsService($http,apiHelper) {
        var service = {
            getLmContacts: getLmContacts
            };            
        return service;
        function getLmContacts() {
         //   return $http.get('http://localhost:8080/api/lmcontacts').then(getLmContactsSuccess).catch(getLmContactsFailure);
            return $http.get(apiHelper.getRootUrl() +'/lmcontacts').then(getLmContactsSuccess).catch(getLmContactsFailure);
            function getLmContactsSuccess(response) {
                return response.data;
            }
            function getLmContactsFailure(error) {
                throw error;
            }
        }
        }
})();



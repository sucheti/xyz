(function (){
    'use strict';

    angular.module('app.layout')
            .constant('lmContanctsConstants', {
                EMAILSUBJECT: "GSESP List Manager",
                EMAILBODYTEXT: "Submit GSESP/LM Question or Issues:"
            });
})();
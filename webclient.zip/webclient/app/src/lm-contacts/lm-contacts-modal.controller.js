(function () {
    'use strict';

    angular
        .module('app.layout')
            .controller('LmContactsController', LmContactsController);

    LmContactsController.$inject = ['lmContactsService', '$uibModalInstance', 'NgTableParams', 'lmContanctsConstants'];

    function LmContactsController(lmContactsService, $uibModalInstance, NgTableParams, lmContanctsConstants) {   
        var vm = this;
        vm.cancelModal = cancelModal;
        vm.openEmail = openEmail;
        activate();

        function activate() {
            vm.tableParams = {
                page: 1, // show first page
                count: 5 // count per page
            };
            vm.data = [];
            vm.searchResult = new NgTableParams(vm.tableParams,
                    {
                        counts: [5, 10, 15, 25],
                        count: vm.data.length,
                        dataset: vm.data

                    });
            getLmContacts();

        }
        function getLmContacts() {
            lmContactsService.getLmContacts()
                    .then(function (data) {
                        vm.searchResult = {};
                        vm.data = data;

                        vm.searchResult = new NgTableParams(vm.tableParams,
                                {
                                    page: 1,
                                    counts: [5, 10, 15, 25],
                                    count: vm.data.length,
                                    dataset: vm.data

                                });

                    });

            vm.searchResult.total(vm.data.length);
            vm.searchResult.reload();
        }
        function openEmail(email) {
            vm.mailLink = "mailto:" + email + "?subject=" + lmContanctsConstants.EMAILSUBJECT + '&body=' + lmContanctsConstants.EMAILBODYTEXT;
        }
        function cancelModal() {
            $uibModalInstance.dismiss('cancel');
        }
    }
})();



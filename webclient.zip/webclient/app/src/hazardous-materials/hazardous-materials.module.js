(function () {
    'use strict';

    angular.module('gsesp.hazardous-materials', [
        'ui.bootstrap'


    ]);
})();


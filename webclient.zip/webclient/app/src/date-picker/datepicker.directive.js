

(function () {
    "use strict";

    angular
            .module('gsesp')
            .directive('gsespNeedByDate', gsespNeedByDate);

    dateController.$inject = ['requestStatus'];
    function gsespNeedByDate() {
        return {
            restict: 'E',
            scope: {},
            bindToController: {
                dateOptions: '=',
                minDate: '=',
                format: '=',
                ngModel: '=',
                initDate: '=',
                details: '='
            },
            templateUrl: 'src/date-picker/date-picker.template.html',
            controller: dateController,
            controllerAs: 'vm'
        };
    }

    function dateController(requestStatus) {
        var vm = this;
        vm.datePickerOpened = false;
        vm.openDatePicker = openDatePicker;
        vm.dateOptions.initDate.setDate(vm.dateOptions.minDate.getDate());
        function openDatePicker() {
            switch (vm.details.status.statusId) {
                case requestStatus.OPEN:
                    vm.datePickerOpened = false;
                    break;
                case requestStatus.COMPLETE:
                case requestStatus.REJECT:
                    vm.datePickerOpened = false;
                    break;
                default:
                    vm.datePickerOpened = true;
            }

        }
    }
})();
(function () {
    'use strict';
    
    angular.module('gsesp.circuit-breakers', [
        'ui.bootstrap',
        'gsesp.coc'
    ]);
})();


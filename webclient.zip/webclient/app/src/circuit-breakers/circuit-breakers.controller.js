(function () {
    'use strict';

    angular.module('gsesp.circuit-breakers')
            .controller('CircuitBreakersController', CircuitBreakersController);

    CircuitBreakersController.$inject = ['$scope', 'requestsService', 'authService', 'masterService', 'growlService', 'messages', 'maxNeedByDate', 'cocService', 'requestTypeConstants', '$stateParams', 'requestStatus', 'FileService', 'masterTypeConstants', '$state', 'requestStatusName', 'searchStateService', 'rejectCodeService', '$uibModal', 'templateName'];
    function CircuitBreakersController($scope, requestsService, authService, masterService, growlService, messages, maxNeedByDate, cocService, requestTypeConstants, $stateParams, requestStatus, FileService, masterTypeConstants, $state, requestStatusName, searchStateService, rejectCodeService, $uibModal, templateName) {
        var vm = this;
        vm.request = {};
        vm.requesterInGet = {};
        vm.form = {};
        vm.isSave = false;
        vm.isSaveAndSubmit = false;
        vm.isShowSave = true;
        vm.isFileName = false;
        vm.isSubmitted = false;
        vm.isResponseComments = true;
        vm.isAllowedManager = false;
        vm.isFileUpload = true;
        vm.isDeleteFile = false;
        vm.isRequestorPhoneNumber = false;
        vm.isReadOnly = false;
        vm.form.$dirty = false;
        vm.isDirtyAlert = true;
        vm.reportName = templateName.CIRCUIT_BREAKERS_REPORT_NAME;

        vm.requestTypeName = requestTypeConstants.CIRCUIT_BREAKERS_REQTYPE_NAME;
        vm.isActive = 1;
        vm.newRequest = newRequest;
        vm.get = get;
        vm.create = create;
        vm.update = update;
        vm.save = save;
        vm.saveAndSubmit = saveAndSubmit;
        vm.complete = complete;
        vm.reject = reject;
        vm.uploadDoc = uploadDoc;
        vm.download = download;
        vm.deleteFile = deleteFile;
        vm.intializeDateOptions = intializeDateOptions;
        vm.validateRequest = validateRequest;
        vm.validateCompleteReject = validateCompleteReject;
        vm.newRequestConfirm = newRequestConfirm;
        vm.updateSearchList = updateSearchList;
        vm.hasChanges = hasChanges;

        // date picker options
        vm.format = 'dd-MMM-yyyy';
        function intializeDateOptions() {
            vm.dateOptions = {
                formatYear: 'yy',
                minDate: new Date(),
                format: 'dd-MMM-yyyy',
                initDate: new Date()
            };
            vm.dateOptions.minDate.setDate(vm.dateOptions.minDate.getDate() + maxNeedByDate.REQUEST_NEED_BYDATE);
            vm.dateOptions.initDate = angular.copy(vm.dateOptions.minDate); 
        }

        initialize();
        function initialize() {
            vm.request.status = {};
            vm.modelOptions = [];
            vm.runReport = runReport;
            vm.isActive = 1;
            vm.isDirtyAlert = true;
            getLoggedInUser();
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.AIRPLANE_MODEL_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.modelOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.DOC_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.doctypeOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.message, 'danger');
                    });


            cocService.getAllCocOption()
                    .then(function (response) {
                        vm.cocList = response;
                        vm.isCoc = {"id": false, "name": "No"};
                    });
            rejectCodeService.get(
                    {
                        requestTypeName: vm.requestTypeName,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.rejectionCodeOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.message, 'danger');
                    });

            intializeDateOptions();
            if (angular.isDefined($stateParams.requestId) && $stateParams.requestId !== '') {
                get($stateParams.requestId);
            } else {
                vm.request.status.statusName = requestStatusName.DRAFT;

            }
        }

        $scope.$on('isFormDirty', function (event) {
            hasChanges();
        });

        function runReport() {
            var uibModalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'src/reports/report-modal.html',
                controller: 'ReportModalController',
                controllerAs: 'vm',
                size: 'reportmodal',
                backdrop: 'static',
                keyboard: true,
                resolve: {
                    parent: function () {
                        return vm;
                    }
                }
            });
        }
        function  newRequest() {
            if (hasChanges()) {
                swal({
                    title: messages.common.dirtyAlertTitleMessage,
                    text: messages.common.nonRecoverTextMessage,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Create a New Request",
                    closeOnConfirm: false
                }, function () {
                    swal(messages.common.createNewRequestSuccessTitleMessage, messages.common.createNewRequestSuccessTextMessage, "success");
                    newRequestConfirm();
                });
            } else {
                newRequestConfirm();
            }
        }
        function newRequestConfirm() {
            vm.form.$submitted = false;
            vm.isSubmitted = false;
            vm.isDownload = false;
            vm.isFileName = false;
            vm.isFileUpload = true;
            searchStateService.isNewRequest = true;
            vm.request = {};
            vm.isCoc = {"id": false, "name": "No"};
            vm.request.requester = {};
            vm.request.status = {};

            getLoggedInUser();
            vm.request.status.statusName = requestStatusName.DRAFT;
            vm.request.status.statusId = requestStatus.DRAFT;
            vm.request.requester = vm.loggedInUser;
            intializeDateOptions();
            $state.go('request.circuit-breakers', {requestId: vm.request.requestId});
            vm.form.$setPristine();
            vm.form.$setUntouched();
        }

        function get(requestId) {
            vm.isFileUpload = false;
            searchStateService.state = {};
            return requestsService.get(
                    {
                        requestTypeName: vm.requestTypeName,
                        requestId: requestId
                    },
                    function (response) {
                        vm.request = response;
                        angular.copy(vm.request, vm.requesterInGet);
                        displayCoc(vm.request.coc);
                        if (angular.isDefined(vm.request.fileName) && vm.request.fileName !== null) {
                            vm.isFileName = true;
                        }
                        vm.isRequestorPhoneNumber = false;
                        enableOrDisable(vm.request);
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });

        }

        function save() {
            vm.form.$submitted = true;
            if (searchStateService.filters.isDraft) {
                searchStateService.state = {};
            }
            if (angular.isDefined(vm.request.requestId)) {
                update();
            } else {
                create();
            }
        }

        function saveAndSubmit() {
            vm.form.$submitted = true;
            vm.request.submit = true;
            if (searchStateService.filters.isOpen) {
                searchStateService.state = {};
            }
            if (angular.isDefined(vm.request.requestId)) {
                update();
            } else {
                create();
            }
        }

        function create() {
            if (validateRequest(vm.request)) {
                setCoc(vm.isCoc);
                requestsService.save({
                    requestTypeName: vm.requestTypeName
                }, vm.request,
                        function (response) {
                            vm.request = response;
                            displayCoc(vm.request.coc);
                            if (vm.request.submit) {
                                growlService.growl(messages.circuitbreakers.circuitbreakersSubmittedSuccessful, 'success');
                            } else {
                                growlService.growl(messages.circuitbreakers.circuitbreakersCreatedSuccessful, 'success');
                            }
                            vm.isDirtyAlert = false;
                            enableOrDisable(response);
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                            $state.go('request.circuit-breakers', {requestId: vm.request.requestId});
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });

            } else {
                growlService.growl(messages.common.enterMandatoryFields, 'danger');
            }
        }
        function update() {
            if (validateRequest(vm.request)) {
                setCoc(vm.isCoc);
                requestsService.update({
                    requestTypeName: vm.requestTypeName,
                    requestId: vm.request.requestId
                }, vm.request,
                        function (response) {
                            vm.request = response;
                            displayCoc(vm.request.coc);
                            if (vm.request.submit) {
                                growlService.growl(messages.circuitbreakers.circuitbreakersSubmittedSuccessful, 'success');
                                updateSearchList();
                            } else {
                                growlService.growl(messages.circuitbreakers.circuitbreakersUpdatedSuccessful, 'success');
                            }
                            vm.isDirtyAlert = false;
                            enableOrDisable(response);
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
            } else {
                growlService.growl(messages.common.enterMandatoryFields, 'danger');
            }
        }


        function complete() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {
                swal({
                    title: messages.common.completeAlertMessage1 + vm.request.requestId + messages.common.completeAlertMessage2,
                    type: "warning",
                    confirmButtonColor: "#3085d6",
                    confirmButtonText: "COMPLETE",
                    showCancelButton: true,
                    closeOnConfirm: true
                }, function () {
                    newCompleteConfirm();
                });
            } else {
                growlService.growl(messages.common.responseComments, 'danger');
            }
        }
        function newCompleteConfirm() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {

                vm.request.requester = vm.requesterInGet.requester;
                return requestsService.complete({
                    requestTypeName: vm.requestTypeName,
                    requestId: vm.request.requestId
                }, vm.request,
                        function (response) {
                            vm.request = response;
                            displayCoc(vm.request.coc);
                            growlService.growl(messages.circuitbreakers.circuitbreakersCompleteRequestSuccessful, 'success');
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                            updateSearchList();
                            enableOrDisable(vm.request);
                            return response;
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
            } else {
                growlService.growl(messages.common.responseComments, 'danger');
            }
        }

        function reject() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {
                var uibModalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'src/requests/reject-code-modal.html',
                    controller: 'RejectCodeController',
                    controllerAs: 'vm',
                    size: 'rejectmodal',
                    backdrop: 'static',
                    keyboard: true,
                    resolve: {
                        parent: function () {
                            return vm;
                        }
                    }
                });
                uibModalInstance.result.then(function (selectedItem) {
                    vm.request.rejectionCodeVO = selectedItem;
                    newRejectConfirm();
                }, function () {
                    // modal dismissed
                });
            } else {
                if (vm.isRejectCode) {
                    growlService.growl(messages.common.rejectCode, 'danger');
                } else {
                    growlService.growl(messages.common.responseComments, 'danger');
                }
            }
        }
        function newRejectConfirm() {
            vm.form.$submitted = true;
            if (validateReject(vm.request)) {
                setCoc(vm.isCoc);
                vm.request.requester = vm.requesterInGet.requester;
                return requestsService.reject(
                        {
                            requestTypeName: vm.requestTypeName,
                            requestId: vm.request.requestId
                        }, vm.request,
                        function (response) {
                            vm.request = response;
                            displayCoc(vm.request.coc);
                            growlService.growl(messages.circuitbreakers.circuitbreakersRejectRequestSuccessful, 'success');
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                            updateSearchList();
                            enableOrDisable(vm.request);
                            return response;
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
            } else {
                growlService.growl(messages.common.responseComments, 'danger');
            }
        }
        function enableOrDisable(requestVO) {
            angular.forEach(vm.loggedInUser.managerItemVOs, function (value, key) {
                var isSearching = true;

                if (isSearching) {
                    if (value.managerItemTypeName === vm.requestTypeName) {
                        vm.isRequestComments = true;
                        vm.isAllowedManager = true;
                        switch (requestVO.status.statusId) {
                            case requestStatus.OPEN:
                                vm.isReadOnly = true;
                                vm.isShowNew = false;
                                vm.isShowSave = false;
                                vm.isShowComplete = true;
                                vm.isRequestStatus = true;
                                vm.isResponseComments = false;
                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = false;
                                vm.isRejectedRequest = false;
                                vm.isAllowedManagerResponseComment = false;
                                break;

                            case requestStatus.COMPLETE:
                                vm.isReadOnly = true;
                                vm.isResponseComments = true;
                                vm.isRequestStatus = true;
                                vm.isShowNew = true;
                                vm.isShowSave = false;
                                vm.isShowComplete = false;
                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = true;
                                vm.isRejectedRequest = false;
                                break;

                            case  requestStatus.REJECT:
                                vm.isReadOnly = true;
                                vm.isResponseComments = true;
                                vm.isRequestStatus = true;
                                vm.isShowNew = true;
                                vm.isShowSave = false;
                                vm.isShowComplete = false;
                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = true;
                                if (angular.isDefined(vm.request.rejectionCodeVO.rejectionCodeDesc)
                                        && vm.request.rejectionCodeVO.rejectionCodeDesc !== ''
                                        && vm.request.rejectionCodeVO.rejectionCodeDesc !== null) {
                                    vm.isRejectedRequest = true;
                                } else {
                                    vm.isRejectedRequest = false;
                                }
                                break;


                            default:
                                vm.isReadOnly = false;
                                vm.isShowNew = false;
                                vm.isShowSave = true;
                                vm.isShowComplete = false;
                                vm.isRequestStatus = true;
                                vm.isResponseComments = true;
                                vm.isRequestComments = false;
                                vm.isRejectedRequest = false;
                                vm.isFileUpload = false;
                                if (vm.request.fileName !== '' && vm.request.fileName !== null) {
                                    vm.isDeleteFile = false;
                                } else {
                                    vm.isDeleteFile = true;
                                }

                                vm.isSubmitted = false;
                                break;
                        }
                        isSearching = false;
                    }
                }

            });
            if (!vm.isAllowedManager) {
                switch (requestVO.status.statusId) {
                    case requestStatus.COMPLETE:
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = true;
                        vm.isRejectedRequest = false;
                        break;
                    case requestStatus.REJECT:
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = true;
                        if (angular.isDefined(vm.request.rejectionCodeVO.rejectionCodeDesc)
                                && vm.request.rejectionCodeVO.rejectionCodeDesc !== ''
                                && vm.request.rejectionCodeVO.rejectionCodeDesc !== null) {
                            vm.isRejectedRequest = true;
                        } else {
                            vm.isRejectedRequest = false;
                        }
                        break;
                    case requestStatus.OPEN :
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isRequestStatus = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = false;
                        vm.isRejectedRequest = false;
                        vm.isAllowedManagerResponseComment = true;
                        break;

                    default:
                        vm.isReadOnly = false;
                        vm.isRequestStatus = true;
                        vm.isShowNew = false;
                        vm.isShowSave = true;
                        vm.isShowComplete = false;
                        vm.isFileUpload = false;
                        vm.isRejectedRequest = false;
                        if (vm.request.fileName !== '' && vm.request.fileName !== null) {
                            vm.isDeleteFile = false;
                        } else {
                            vm.isDeleteFile = true;
                        }
                        vm.isSubmitted = false;
                        break;
                }

            }
            if (angular.isDefined(vm.request.fileName) && vm.request.fileName !== null) {
                vm.isFileName = true;

            }
            if (vm.request.requester !== null && vm.request.requester.phoneNumber !== null) {
                vm.isRequestorPhoneNumber = true;
            }

            if (vm.request.manager !== null && vm.request.manager.phoneNumber !== null) {
                vm.isManagerPhoneNumber = true;
            }

        }

        function uploadDoc() {
            if (vm.myFile) {
                FileService.uploadDoc(vm.myFile, vm.request.requestId, vm.requestTypeName)
                        .then(function (response) {
                            vm.myFile = null;
                            vm.isDownload = true;
                            vm.request.fileName = response.fileName;
                            growlService.growl(messages.common.fileUploadSuccess, 'success');
                            vm.isDeleteFile = false;
                        }).catch(function (error) {
                    growlService.growl(error.message, 'danger');
                });
            }
        }

        function download() {
            FileService.download(vm.requestTypeName, vm.request.requestId).success(function () {

            }).error(function () {
                growlService.growl(messages.common.fileDownloadFail, 'danger');
            });

        }

        function deleteFile() {
            FileService.deleteFile(vm.requestTypeName, vm.request.requestId)
                    .then(function (response) {
                        growlService.growl(messages.common.fileDeleteSuccess, 'success');
                        vm.isDownload = false;
                        vm.isFileName = false;
                        vm.request.fileName = "";
                    }).catch(function (error) {
                growlService.growl(messages.common.fileDeleteFail, 'danger');
                vm.isDownload = true;
            });
        }

        function displayCoc(data) {
            if (data) {
                vm.isCoc = {id: true, "name": "Yes"};
            } else {
                vm.isCoc = {id: false, "name": "No"};
            }
        }

        function setCoc(data) {
            if (data.id) {
                vm.request.coc = true;
            } else {
                vm.request.coc = false;
            }
        }
        function validateRequest(request) {
            if (angular.isUndefined(request.equipmentNumber)) {
                return false;
            }
            if (angular.isUndefined(request.circuitBreakerName)) {
                return false;
            }
            if (angular.isUndefined(request.panelRow)) {
                return false;
            }
            if (angular.isUndefined(request.panelColumn)) {
                return false;
            }
            if (angular.isUndefined(request.needByDate) || request.needByDate === null) {
                return false;
            }
            if (angular.isUndefined(request.airplaneModels)) {
                return false;
            }
            if (angular.isUndefined(request.docTypes)) {
                return false;
            }

            return true;
        }

        function validateCompleteReject(request) {
            if (request.status.statusId === requestStatus.OPEN) {
                if (angular.isUndefined(request.responseComments)
                        || request.responseComments === null || request.responseComments === '') {
                    return false;
                }
            }
            return true;
        }
        function validateReject(request) {
            vm.isRejectCode = false;
            if (angular.isUndefined(request.rejectionCodeVO) ||
                    request.rejectionCodeVO.rejectionId === null
                    || request.rejectionCodeVO.rejectionId === ''
                    || request.rejectionCodeVO.rejectionId === 0
                    || request.rejectionCodeVO === 'NO') {
                vm.isRejectCode = true;
                return false;
            }
            return true;
        }

        function updateSearchList() {
            $scope.$emit('updateSearchList', {});
        }
        function hasChanges() {
            if (vm.form.$dirty) {
                searchStateService.hasChanges = true;
                return true;
            } else {
                searchStateService.hasChanges = false;
                return false;
            }
        }


        function getLoggedInUser() {
            authService.getUserDetails()
                    .then(function (response) {
                        vm.request.requester = response;
                        vm.loggedInUser = vm.request.requester;
                        if (vm.loggedInUser.phoneNumber !== null) {
                            vm.isRequestorPhoneNumber = true;
                        }
                    }).catch(function (error) {
                growlService.growl(error.message, 'danger');
            });
        }
    }
})();


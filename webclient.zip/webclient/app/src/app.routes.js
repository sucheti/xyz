(function(){
    'use strict';
    
    angular
        .module('gsesp')
        .run(appRun);
    
    appRun.$inject = ['routerHelper'];
    
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates(), '/');                
    }     
    
    function getStates() {
        return [];
    } 
})();
(function () {
    'use strict';
    angular.module('gsesp.acronyms-abbrev')
            .controller('AcronymsAbbrevController', AcronymsAbbrevController);
    AcronymsAbbrevController.$inject = ['$uibModal', 'rejectCodeService', '$scope', 'abbreviationConstants', 'searchStateService', 'requestsService', 'growlService', 'messages', 'maxNeedByDate', '$stateParams', 'requestTypeConstants', 'requestStatus', 'FileService', 'authService', 'masterService', 'masterTypeConstants', 'requestStatusName', '$state', 'templateName'];
    function AcronymsAbbrevController($uibModal, rejectCodeService, $scope, abbreviationConstants, searchStateService, requestsService, growlService, messages, maxNeedByDate, $stateParams, requestTypeConstants, requestStatus, FileService, authService, masterService, masterTypeConstants, requestStatusName, $state, templateName) {
        var vm = this;

        vm.request = {};
        vm.requesterInGet = {};
        vm.isSave = false;
        vm.isSaveAndSubmit = false;
        vm.isShowSave = true;
        vm.isDocTypeRequiredInfoCode = false;
        vm.isFileName = false;
        vm.isDownload = false;
        vm.isFileUpload = true;
        vm.isDeleteFile = false;
        vm.isResponseComments = true;
        vm.isAllowedManager = false;
        vm.isRequestorPhoneNumber = false;
        vm.isReadOnly = false;
        vm.isDirtyAlert = true;
        vm.requestTypeName = requestTypeConstants.ACRONYMSABBREV_REQTYPE_NAME;
        vm.isActive = abbreviationConstants.IS_ACTIVE;
        vm.abbreviation = abbreviationConstants.ABBREVIATION_FALSE;
        vm.reportName = templateName.ACRONYMS_REPORT_NAME;

        vm.newRequest = newRequest;
        vm.save = save;
        vm.saveAndSubmit = saveAndSubmit;
        vm.complete = complete;
        vm.reject = reject;
        vm.update = update;
        vm.create = create;
        vm.download = download;
        vm.deleteFile = deleteFile;
        vm.newRequestConfirm = newRequestConfirm;
        vm.hasChanges = hasChanges;
        vm.get = get;
        vm.uploadDoc = uploadDoc;
        vm.intializeDateOptions = intializeDateOptions;
        vm.validateRequest = validateRequest;
        vm.validateCompleteReject = validateCompleteReject;
        vm.updateSearchList = updateSearchList;
        vm.runReport = runReport;

        // date picker options
        vm.datePickerOpened = false;
        vm.format = 'dd-MMM-yyyy';
        function intializeDateOptions() {
            vm.dateOptions = {
                formatYear: 'yy',
                minDate: new Date(),
                format: 'dd-MMM-yyyy',
                initDate: new Date()
            };
            vm.dateOptions.minDate.setDate(vm.dateOptions.minDate.getDate() + maxNeedByDate.REQUEST_NEED_BYDATE);
            vm.dateOptions.initDate.setDate(vm.dateOptions.minDate.getDate());
        }

        initialize();
        function initialize() {
            vm.request.status = {};
            vm.modelOptions = [];
            vm.isDirtyAlert = true;
            getLoggedInUser();
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.AIRPLANE_MODEL_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.modelOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            masterService.query(
                    {
                        masterTypeName: masterTypeConstants.DOC_TYPE,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.doctypeOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
            rejectCodeService.get(
                    {
                        requestTypeName: vm.requestTypeName,
                        isActive: vm.isActive
                    },
                    function (response) {
                        vm.rejectionCodeOptions = response;
                    },
                    function (error) {
                        growlService.growl(error.message, 'danger');
                    });
            vm.isResponseComments = true;
            intializeDateOptions();

            if ($stateParams.requestId !== '' && $stateParams.requestId !== null) {
                get($stateParams.requestId);
            } else {
                vm.request.status.statusName = requestStatusName.DRAFT;
                vm.isCoc = {"id": false, "name": "No"};
                vm.request.abbreviation = abbreviationConstants.ABBREVIATION_FALSE;
                vm.isFileUpload = true;
            }
        }
        $scope.$on('isFormDirty', function (event) {
            hasChanges();
        });

        function  newRequest() {
            vm.form.$submitted = false;
            if (hasChanges()) {
                swal({
                    title: messages.common.dirtyAlertTitleMessage,
                    text: messages.common.nonRecoverTextMessage,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Create a New Request",
                    closeOnConfirm: false
                }, function () {
                    swal(messages.common.createNewRequestSuccessTitleMessage, messages.common.createNewRequestSuccessTextMessage, "success");
                    newRequestConfirm();
                });
            } else {
                newRequestConfirm();
            }
        }

        function newRequestConfirm() {
            vm.form.$submitted = false;
            vm.request = {};
            vm.request.requester = {};
            vm.request.status = {};
            vm.isSubmitted = false;
            vm.isFileName = false;
            vm.isFileUpload = true;
            vm.request.abbreviation = abbreviationConstants.ABBREVIATION_FALSE;
            searchStateService.isNewRequest = true;
            vm.request.warning = true;
            vm.isCoc = {"id": false, "name": "No"};
            vm.request.requester = {};
            vm.request.status = {};
            getLoggedInUser();
            intializeDateOptions();
            vm.request.status.statusName = requestStatusName.DRAFT;
            vm.request.status.statusId = requestStatus.DRAFT;
            $state.go('request.acronyms-abbrev', {requestId: vm.request.requestId});
            vm.form.$setPristine();
            vm.form.$setUntouched();
        }
        function get(requestId) {
            searchStateService.state = {};
            return requestsService.get(
                    {
                        requestTypeName: requestTypeConstants.ACRONYMSABBREV_REQTYPE_NAME,
                        requestId: requestId
                    },
                    function (response) {
                        vm.request = response;
                        angular.copy(vm.request, vm.requesterInGet);
                        displayAcronymAbbrev(vm.request.abbreviation);
                        if (angular.isDefined(vm.request.fileName) && vm.request.fileName !== null) {
                            vm.isFileName = true;
                        }
                        vm.isRequestorPhoneNumber = false;
                        enableOrDisable(vm.request);
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });
        }

        function save() {
            vm.form.$submitted = true;
            setAcronymAbbrev(vm.request.abbreviation);
            if (searchStateService.filters.isDraft) {
                searchStateService.state = {};
            }

            if (angular.isDefined(vm.request.requestId)) {

                update();
            } else {

                create();
            }
        }

        function saveAndSubmit() {
            vm.form.$submitted = true;
            vm.request.submit = true;
            setAcronymAbbrev(vm.request.abbreviation);
            if (searchStateService.filters.isOpen) {
                searchStateService.state = {};
            }
            if (angular.isDefined(vm.request.requestId)) {

                update();
            } else {

                create();
            }
        }

        function create() {
            if (validateRequest(vm.request)) {
                requestsService.save({
                    requestTypeName: vm.requestTypeName}, vm.request,
                        function (response) {
                            vm.request = response;
                            displayAcronymAbbrev(vm.request.abbreviation);
                            vm.isRequestStatus = true;
                            if (vm.request.submit) {
                                growlService.growl(messages.acronyms.acronymsSaveAndSubmitSuccessful, 'success');
                            } else {
                                growlService.growl(messages.acronyms.acronymsCreateSuccessful, 'success');
                            }
                            vm.isDirtyAlert = false;
                            enableOrDisable(response);
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                            $state.go('request.acronyms-abbrev', {requestId: vm.request.requestId});
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        }
                );
            } else {
                vm.request.abbreviation = vm.abbreviation;
                growlService.growl(messages.common.enterMandatoryFields, 'danger');
            }
        }
        function update() {
            if (validateRequest(vm.request)) {
                requestsService.update({
                    requestTypeName: vm.requestTypeName,
                    requestId: vm.request.requestId
                }, vm.request,
                        function (response) {
                            vm.request = response;
                            vm.isRequestStatus = true;
                            vm.abbreviation = response.abbreviation;
                            displayAcronymAbbrev(vm.request.abbreviation);
                            if (vm.request.submit) {
                                growlService.growl(messages.acronyms.acronymsSaveAndSubmitSuccessful, 'success');
                                updateSearchList();
                            } else {
                                growlService.growl(messages.acronyms.acronymsUpdateSuccessful, 'success');
                            }
                            vm.isDirtyAlert = false;
                            enableOrDisable(response);
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        }
                );
            } else {
                growlService.growl(messages.common.enterMandatoryFields, 'danger');
            }
        }

        function complete() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {
                swal({
                    title: messages.common.completeAlertMessage1 + vm.request.requestId + messages.common.completeAlertMessage2,
                    type: "warning",
                    confirmButtonColor: "#3085d6",
                    confirmButtonText: "COMPLETE",
                    showCancelButton: true,
                    closeOnConfirm: true
                }, function () {
                    newCompleteConfirm();
                });
            } else {
                growlService.growl(messages.common.responseComments, 'danger');
            }
        }
        function newCompleteConfirm() {
            vm.form.$submitted = true;
            setAcronymAbbrev(vm.request.abbreviation);
            vm.request.requester = vm.requesterInGet.requester;
            return requestsService.complete({
                requestTypeName: vm.requestTypeName,
                requestId: vm.request.requestId
            }, vm.request,
                    function (response) {
                        vm.request = response;
                        displayAcronymAbbrev(vm.request.abbreviation);
                        updateSearchList();
                        enableOrDisable(response);
                        growlService.growl(messages.acronyms.acronymsCompleteRequestSuccessful, 'success');
                        vm.form.$setPristine();
                        vm.form.$setUntouched();
                        return response;
                    },
                    function (error) {
                        growlService.growl(error.data.message, 'danger');
                    });

        }
        function reject() {
            vm.form.$submitted = true;
            if (validateCompleteReject(vm.request)) {
                var uibModalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'src/requests/reject-code-modal.html',
                    controller: 'RejectCodeController',
                    controllerAs: 'vm',
                    size: 'rejectmodal',
                    backdrop: 'static',
                    keyboard: true,
                    resolve: {
                        parent: function () {
                            return vm;
                        }
                    }
                });
                uibModalInstance.result.then(function (selectedItem) {
                    vm.request.rejectionCodeVO = selectedItem;
                    newRejectConfirm();
                }, function () {
                    // modal dismissed
                });
            } else {
                if (vm.isRejectCode) {
                    growlService.growl(messages.common.rejectCode, 'danger');
                } else {
                    growlService.growl(messages.common.responseComments, 'danger');
                }
            }
        }
        function newRejectConfirm() {
            if (validateReject(vm.request)) {
                vm.form.$submitted = true;
                setAcronymAbbrev(vm.request.abbreviation);
                vm.request.requester = vm.requesterInGet.requester;
                return requestsService.reject({
                    requestTypeName: vm.requestTypeName,
                    requestId: vm.request.requestId
                }, vm.request,
                        function (response) {
                            vm.request = response;
                            displayAcronymAbbrev(vm.request.abbreviation);
                            updateSearchList();
                            enableOrDisable(response);
                            growlService.growl(messages.acronyms.acronymsRejectRequestSuccessful, 'success');
                            vm.form.$setPristine();
                            vm.form.$setUntouched();
                            return response;
                        },
                        function (error) {
                            growlService.growl(error.data.message, 'danger');
                        });
            } else {
                growlService.growl(messages.common.responseComments, 'danger');
            }
        }
        function enableOrDisable(requestVO) {

            angular.forEach(vm.loggedInUser.managerItemVOs, function (value, key) {
                var isSearching = true;


                if (isSearching) {
                    if (value.managerItemTypeName === requestTypeConstants.ACRONYMSABBREV_REQTYPE_NAME) {

                        vm.isRequestComments = true;
                        vm.isAllowedManager = true;
                        switch (requestVO.status.statusId) {
                            case requestStatus.OPEN:
                                vm.isReadOnly = true;
                                vm.isShowNew = false;
                                vm.isShowSave = false;
                                vm.isShowComplete = true;
                                vm.isRequestStatus = true;
                                vm.isRejectedRequest = false;
                                vm.isResponseComments = false;
                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = false;
                                vm.isAllowedManagerResponseComment = false;
                                break;
                            case requestStatus.COMPLETE:
                                vm.isReadOnly = true;
                                vm.isResponseComments = true;
                                vm.isShowNew = true;
                                vm.isShowSave = false;
                                vm.isShowComplete = false;
                                vm.isFileUpload = true;
                                vm.isRequestStatus = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = true;
                                vm.isRejectedRequest = false;
                                break;
                            case requestStatus.REJECT:
                                vm.isReadOnly = true;
                                vm.isResponseComments = true;
                                vm.isShowNew = true;
                                vm.isShowSave = false;
                                vm.isShowComplete = false;
                                vm.isRequestStatus = true;
                                vm.isFileUpload = true;
                                vm.isDeleteFile = true;
                                vm.isSubmitted = true;
                                if (angular.isDefined(vm.request.rejectionCodeVO.rejectionCodeDesc)
                                        && vm.request.rejectionCodeVO.rejectionCodeDesc !== ''
                                        && vm.request.rejectionCodeVO.rejectionCodeDesc !== null) {
                                    vm.isRejectedRequest = true;
                                } else {
                                    vm.isRejectedRequest = false;
                                }
                                break;
                            default:
                                vm.isReadOnly = false;
                                vm.isShowNew = false;
                                vm.isShowSave = true;
                                vm.isShowComplete = false;
                                vm.isResponseComments = true;
                                vm.isRequestComments = false;
                                vm.isRequestStatus = true;
                                vm.isRejectedRequest = false;
                                vm.isFileUpload = false;
                                vm.isSubmitted = false;
                                if (vm.request.fileName !== '' && vm.request.fileName !== null) {
                                    vm.isDeleteFile = false;
                                } else {
                                    vm.isDeleteFile = true;
                                }
                                break;
                        }
                        isSearching = false;
                    }
                }

            }
            );
            if (!vm.isAllowedManager) {

                switch (requestVO.status.statusId) {
                    case requestStatus.COMPLETE:
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        vm.isRejectedRequest = false;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = true;
                        break;
                    case requestStatus.REJECT :
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        if (angular.isDefined(vm.request.rejectionCodeVO.rejectionCodeDesc)
                                && vm.request.rejectionCodeVO.rejectionCodeDesc !== ''
                                && vm.request.rejectionCodeVO.rejectionCodeDesc !== null) {
                            vm.isRejectedRequest = true;
                        } else {
                            vm.isRejectedRequest = false;
                        }
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = true;
                        break;
                    case requestStatus.OPEN :
                        vm.isReadOnly = true;
                        vm.isRequestComments = true;
                        vm.isShowNew = true;
                        vm.isShowSave = false;
                        vm.isRequestStatus = true;
                        vm.isRejectedRequest = false;
                        vm.isShowComplete = false;
                        vm.isFileUpload = true;
                        vm.isDeleteFile = true;
                        vm.isSubmitted = false;
                        vm.isAllowedManagerResponseComment = true;
                        break;
                    default:
                        vm.isReadOnly = false;
                        vm.isShowNew = false;
                        vm.isShowSave = true;
                        vm.isShowComplete = false;
                        vm.isFileUpload = false;
                        vm.isRequestStatus = true;
                        vm.isRejectedRequest = false;
                        vm.isDeleteFile = false;
                        vm.isSubmitted = false;
                        if (vm.request.fileName !== '' && vm.request.fileName !== null) {
                            vm.isDeleteFile = false;
                        } else {
                            vm.isDeleteFile = true;
                        }
                        break;
                }
            }

            if (angular.isDefined(vm.request.fileName) && vm.request.fileName !== null) {

                vm.isFileName = true;
            }
            if (vm.request.requester !== null && vm.request.requester.phoneNumber !== null) {
                vm.isRequestorPhoneNumber = true;
            }

            if (vm.request.manager !== null && vm.request.manager.phoneNumber !== null) {
                vm.isManagerPhoneNumber = true;
            }

        }
        function uploadDoc() {
            if (vm.myFile) {
                FileService.uploadDoc(vm.myFile, vm.request.requestId, vm.requestTypeName)
                        .then(function (result) {
                            vm.myFile = null;
                            vm.isFileName = true;
                            vm.isDownload = true;
                            vm.request.fileName = result.fileName;
                            vm.isDeleteFile = false;
                            growlService.growl(messages.common.fileUploadSuccess, 'success');
                        }).catch(function (error) {
                    growlService.growl(error.message, 'danger');
                });
            }

        }
        function download() {
            FileService.download(vm.requestTypeName, vm.request.requestId).success(function () {

            }).error(function () {
                growlService.growl(messages.common.fileDownloadFail, 'danger');
            });

        }

        function deleteFile() {
            FileService.deleteFile(vm.requestTypeName, vm.request.requestId)
                    .then(function (result) {
                        growlService.growl(messages.common.fileDeleteSuccess, 'success');
                        vm.isDeleteFile = true;
                        vm.isFileName = false;
                        vm.request.fileName = "";
                    }).catch(function (error) {
                growlService.growl(error.message, 'danger');
                vm.isDownload = true;
            });
        }



        function setAcronymAbbrev(data) {
            if (parseInt(data) === 1) {
                vm.abbreviation = abbreviationConstants.ABBREVIATION_TRUE;
                vm.request.abbreviation = true;
                vm.request.acronym = false;
            } else {
                vm.abbreviation = abbreviationConstants.ABBREVIATION_FALSE;
                vm.request.abbreviation = false;
                vm.request.acronym = true;
            }

        }
        function displayAcronymAbbrev(data) {
            if (data) {
                vm.request.abbreviation = abbreviationConstants.ABBREVIATION_TRUE;
            } else {
                vm.request.abbreviation = abbreviationConstants.ABBREVIATION_FALSE;
            }
        }
        function validateRequest(request) {

            if (angular.isUndefined(request.expandedText)) {
                return false;
            }
            if (angular.isUndefined(request.needByDate) || request.needByDate === null) {
                return false;
            }
            if (angular.isUndefined(request.airplaneModels)) {
                return false;
            }
            if (angular.isUndefined(request.docTypes)) {
                return false;
            }
            return true;
        }
        function validateReject(request) {
            vm.isRejectCode = false;
            if (angular.isUndefined(request.rejectionCodeVO) ||
                    request.rejectionCodeVO.rejectionId === null
                    || request.rejectionCodeVO.rejectionId === ''
                    || request.rejectionCodeVO.rejectionId === 0
                    || request.rejectionCodeVO === 'NO') {
                vm.isRejectCode = true;
                return false;
            }
            return true;
        }
        function validateCompleteReject(request) {
            if (request.status.statusId === requestStatus.OPEN) {
                if (angular.isUndefined(request.responseComments)
                        || request.responseComments === null || request.responseComments === '') {
                    return false;
                }
            }
            return true;
        }
        function hasChanges() {
            if (vm.form.$dirty) {
                searchStateService.hasChanges = true;
                return true;
            } else {
                searchStateService.hasChanges = false;
                return false;
            }
        }
        function updateSearchList() {
            $scope.$emit('updateSearchList', {});
        }

        function getLoggedInUser() {
            authService.getUserDetails()
                    .then(function (response) {
                        vm.request.requester = response;
                        vm.loggedInUser = vm.request.requester;
                        if (vm.loggedInUser.phoneNumber !== null) {
                            vm.isRequestorPhoneNumber = true;
                        }
                    }).catch(function (error) {
                growlService.growl(error.message, 'danger');
            });
            ;
        }

        //Run report modal dialog
        function runReport() {
            var uibModalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'src/reports/report-modal.html',
                controller: 'ReportModalController',
                controllerAs: 'vm',
                size: 'reportmodal',
                backdrop: 'static',
                keyboard: true,
                resolve: {
                    parent: function () {
                        return vm;
                    }
                }
            });
        }
    }
})();


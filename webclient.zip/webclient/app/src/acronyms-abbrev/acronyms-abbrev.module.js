(function () {
    'use strict';

    angular.module('gsesp.acronyms-abbrev', [
        'ui.bootstrap'
    ]);
})();


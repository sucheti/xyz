(function () {
    'use strict';
    angular.module('gsesp.acronyms-abbrev')
            .constant('abbreviationConstants', {
                IS_ACTIVE: 1,
                ABBREVIATION_FALSE: 2,
                ABBREVIATION_TRUE: 1
            });
})();
(function(exports){

    exports.accessLevels = {
        all: ['READ ONLY', 'REQUESTER', 'ADMINISTRATOR'],
        requester: ['REQUESTER'],
        admin: ['ADMINISTRATOR'],
        readonly: ['READ ONLY']
    };

})(typeof exports === 'undefined'? this['routingConfig']={}: exports);

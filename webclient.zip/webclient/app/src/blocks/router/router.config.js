(function() {
    'use strict';
    
    angular
        .module('blocks.router')
        .run(configure);
    
    configure.$inject = ['$rootScope', '$state'];
    
    function configure($rootScope, $state) {
        // configure ui router to allow a state to redirect to another state as the default behavior
        $rootScope.$on('$stateChangeStart', function (event, to, params) {
            if(to.redirectTo) {
                event.preventDefault();
                $state.go(to.redirectTo, params);
            }
        });
    }
})();
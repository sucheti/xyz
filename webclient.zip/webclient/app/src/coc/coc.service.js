(function () {
    'use strict';

    angular
            .module('gsesp.coc')
            .factory('cocService', cocService);

    cocService.$inject = ['$http', 'apiHelper'];

    function cocService($http, apiHelper) {

        var service = {
            getAllCocOption: getAllCocOption
        };

        return service;


        function getAllCocOption() {
            return $http.get('src/coc/data/coc.json')
                    .then(getAllCocOptionSuccess);

            function getAllCocOptionSuccess(response) {
                return response.data;
            }
        }


    }
})();



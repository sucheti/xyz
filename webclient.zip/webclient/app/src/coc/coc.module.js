(function () {
    'use strict';

    angular.module('gsesp.coc', [
        'ui.bootstrap'
    ]);
})();
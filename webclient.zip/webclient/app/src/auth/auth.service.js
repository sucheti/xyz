(function (){
    'use strict';

    angular
            .module('gsesp.auth')
            .service('authService',authService);

    authService.$inject = ['$http','apiHelper'];

    function authService($http,apiHelper){

        var accessLevels = routingConfig.accessLevels;
        var userRoles = routingConfig.userRoles;
        var currentUser;
        return {
            authorize : authorize,
            getUser : getUser,
            getUserDetails : getUserDetails,
            accessLevels : accessLevels,
            userRoles : userRoles,
            user : currentUser,
            updateLoggedInUser: updateLoggedInUser
        };

        function authorize(accessLevel){
            var role = getUser().userRoleVO.roleName;
            if(role){
                if(routingConfig.accessLevels[accessLevel].indexOf(role.toUpperCase()) !== -1){
                    return true;
                }
            }
            return false;

        }

        function getUserDetails(){
            return $http.get(apiHelper.getRootUrl()+'/currentUser')
                    .then(getAlluserDetailsSuccess)
                    .catch(getAlluserDetailsFailure);

            function getAlluserDetailsSuccess(response){             
                currentUser = response.data;
                return currentUser;
            }
            function getAlluserDetailsFailure(error){
                throw error;             
                // handle error
            }
        }

        function updateLoggedInUser(updateUserDetails) {
            currentUser = updateUserDetails;
        }
        function getUser() {
            return currentUser;
        }

    }
})();

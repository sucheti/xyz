(function () {
    "use strict";

    angular.module('gsesp.auth')
            .directive('visibilityAccessLevel', ['authService', function (authService) {
                    return {
                        restrict: 'A',
                        link: function (scope, element, attrs) {
                            var prevDisp = element.css('display');
                            if (!authService.authorize(attrs.visibilityAccessLevel))
                                element.css('display', 'none');
                            else
                                element.css('display', prevDisp);

                        }
                    };
                }])
            .directive('editableAccessLevel', ['authService', function (authService) {
                    return {
                        restrict: 'A',
                        link: function (scope, element, attrs) {
                            if (authService.authorize(attrs.editableAccessLevel)) {
                                element.attr('readonly', false);
                                element.attr('disabled', false);
                            } else {
                                element.attr('readonly', true);
                                element.attr('disabled', true);
                            }
                        }
                    };
                }]);

})();
(function() {
    'use strict';
    
    angular.module('gsesp.auth', []);
})();
(function () {
    'use strict';

    angular.module('gsesp.infoCode', [
        'ui.bootstrap'
    ]);
})();

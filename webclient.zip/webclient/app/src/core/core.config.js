(function (){
    'use strict';

    angular
            .module('app.core')
            .config(cacheConfig)
            .run(appRun);

    cacheConfig.$inject = ['$httpProvider'];
    appRun.$inject = ['authService','$state','$window'];
    function appRun(authService,$state,$window){
        //Invoke getUser from service on load
        authService.getUserDetails().then(function (result){
            // Do nothing
            if(result === ''){
                $window.location.href = '/gsesp/error.html';
            }
        }).catch(function (error){
            //Handle error
            $window.location.href = '/gsesp/error.html';

        });
    }
    function cacheConfig($httpProvider){
        //initialize get if not there
        if(!$httpProvider.defaults.headers.get){
            $httpProvider.defaults.headers.get = {};
        }
        //disable IE ajax request caching
        $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
        // extra
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    }
})();


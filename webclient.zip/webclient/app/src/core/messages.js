(function () {
    'use strict';

    angular
            .module('app.core')
            .constant('messages', {
                hazardousMaterials: {
                    hazardousMaterialsSaveSuccessful: 'Hazardous Materials saved successful',
                    hazardousMaterialsUpdateSuccessful: 'Hazardous Materials Update successful',
                    hazardousMaterialsSaveAndSubmitSuccessful: 'Hazardous Materials saved and sumbitted successfully',
                    hazardousMaterialsCompleteRequestSuccessful: 'Hazardous Materials request completed successfully',
                    hazardousMaterialsRejectRequestSuccessful: 'Hazardous Materials request rejected successfully'
                },
                zones: {
                    zonesSaveSuccessful: 'Zones Request updated successfully',
                    zonesSaveAndSubmitSuccessful: 'Zones Request saved and sumbitted successfully',
                    zonesCompleteRequestSuccessful: 'Zones Request request completed successfully',
                    zonesRejectRequestSuccessful: 'Zones Request request rejected successfully',
                    zonesCreateSuccessful: 'Zones Request Created Successfully'
                },
                infocode: {
                    infocodeSaveSuccessful: 'Infocode saved successful',
                    infocodeSaveAndSubmitSuccessful: 'Infocode saved and sumbitted successfully',
                    infocodeCompleteRequestSuccessful: 'Infocode request completed successfully',
                    infocodeRejectRequestSuccessful: 'Infocode request rejected successfully',
                    infocodeCreateRequestSuccessful: 'Infocode created successfully'
                },
                sns: {
                    snsCreateSuccessful: 'SNS Request Created successful',
                    snsUpdateSuccessful: 'SNS Request Updated successfully',
                    snsSumbitSuccessful: 'SNS Request Submitted successfully',
                    snsCompleteRequestSuccessful: 'SNS Request completed successfully',
                        snsRejectRequestSuccessful: 'SNS Request rejected successfully'
                },
                accesspanel: {
                    accesspanelCreateSuccessful: 'Access Panel Created successfully',
                    accesspanelSubmiitSuccessful: 'Access Panel Submitted successfully',
                    accesspanelUpdatedSuccessful: 'Access Panel Updated successfully',
                    accesspanelCompleteRequestSuccessful: 'Access Panel request completed successfully',
                    accesspanelRejectRequestSuccessful: 'Access Panel request rejected successfully'
                },
                circuitbreakers : {
                    circuitbreakersCreatedSuccessful : 'Circuit Breakers Request Created successfully',
                    circuitbreakersSubmittedSuccessful : 'Circuit Breakers Request Submitted successfully',
                    circuitbreakersUpdatedSuccessful : 'Circuit Breakers Request Updated successfully',
                    circuitbreakersCompleteRequestSuccessful : 'Circuit Breakers Request completed successfully',
                    circuitbreakersRejectRequestSuccessful : 'Circuit Breakers Request rejected successfully'
                    
                },
                applicability: {
                    applicabilitySaveSuccessful: 'Applicability Created successfully',
                    applicabilityUpdateSuccessful: 'Applicability Request Updated successfully',
                    applicabilityCompleteRequestSuccessful: 'Applicability request completed successfully',
                    applicabilityRejectRequestSuccessful: 'Applicability request rejected successfully',
                    applicabilitySubmiitSuccessful: 'Applicability Submitted successfully'
                },
                common: {
                    enterMandatoryFields: 'Please Enter Mandatory Fields',
                    fileUploadSuccess: 'File Successfully Uploaded',
                    fileDeleteSuccess: 'File Successfully Deleted',
                    fileDeleteFail: 'Cannot delete the file',
                    fileDownloadFail: 'Cannot download the file',
                    responseComments: 'Response Comments is Mandatory',
                    rejectCode: 'Reject Code is Mandatory when rejecting a request',
                    dirtyAlertTitleMessage: 'All your changes will be lost',
                    nonRecoverTextMessage: 'All your changes will be lost. Are you sure you want to do this?',
                    createNewRequestSuccessTitleMessage: 'Creating!',
                    createNewRequestSuccessTextMessage: 'You are now creating new Request!',
                    searchValidateMessage: 'Please Enter Valid Data',
                    completeAlertMessage1: 'Complete request ',
                    completeAlertMessage2: ' ?',
                    rejectAlertMessage1: 'Reject request ',
                    rejectAlertMessage2: ' with rejection code ?',
                    ataSubjectLength: 'Please Enter  only 2 charactes',
                    deleteMasterFields: 'Please select a Row',
                    editMasterFields: 'Please select a Row',
                    invalidFieldLength: 'Entered data is in invalid length',
                    deleteAlertMessage1: 'Are you sure you want to delete this ',
                    deleteAlertMessage2: ' ?'
                },
                cautionsWarnings: {
                    cautionsWarningsUpdateSuccessful: 'Cautions Warnings Updated successfully',
                    cautionsWarningsSaveAndSubmitSuccessful: 'Cautions Warnings saved and sumbitted successfully',
                    cautionsWarningsCompleteRequestSuccessful: 'Cautions Warnings request completed successfully',
                    cautionsWarningsRejectRequestSuccessful: 'Cautions Warnings request rejected successfully',
                    cautionsWarningsCreateSuccessful: 'Cautions Warnings request created successfully'
                },
                tools: {
                    toolsSaveSuccessful: 'Tools Requirement request saved successful',
                    toolsSaveAndSubmitSuccessful: 'Tools Requirement request saved and sumbitted successfully',
                    toolsCompleteRequestSuccessful: 'Tools Requirement request completed successfully',
                    toolsRejectRequestSuccessful: 'Tools Requirement request rejected successfully',
                    toolsEngineerSubmitSuccessful: " Manager for selected Responsible Group saved successfully"
                },
                consumables: {
                    consumablesSaveSuccessful: 'Consumables saved successful',
                    consumablesSaveAndSubmitSuccessful: 'Consumables saved and sumbitted successfully',
                    consumablesCompleteRequestSuccessful: 'Consumables request completed successfully',
                    consumablesRejectRequestSuccessful: 'Consumables request rejected successfully'
                },
                disassemblyCode: {
                    disassemblyCodeSaveSuccessful: 'Disassembly Code saved successful',
                    disassemblyCodeSaveAndSubmitSuccessful: 'Disassembly Code and sumbitted successfully',
                    disassemblyCodeCompleteRequestSuccessful: 'Disassembly Code request completed successfully',
                    disassemblyCodeRejectRequestSuccessful: 'Disassembly Code request rejected successfully',
                    dupilicateVariantCode: 'Please enter unique variant codes',
                    disassemblyCodeVariantCodeMandatory: "Disassembly Variant code is Mandatory for the given Variant name/Variant Internal name/Action"
                },
                sourcedata: {
                    sourcedataCreateSuccessful: 'Source Data Created successful',
                    sourcedataSaveSuccessful: 'Source Data saved successful',
                    sourcedataSubmitSuccessful: 'Source Data request submitted successfully',
                    sourcedataCompleteRequestSuccessful: 'Source Data request completed successfully',
                    sourcedataRejectRequestSuccessful: 'Source Data request rejected successfully'
                },
                acronyms: {
                    acronymsUpdateSuccessful: 'Acronyms Updated successfully',
                    acronymsSaveAndSubmitSuccessful: 'Acronyms sumbitted successfully',
                    acronymsCompleteRequestSuccessful: 'Acronyms request completed successfully',
                    acronymsRejectRequestSuccessful: 'Acronyms request rejected successfully',
                    acronymsCreateSuccessful: 'Acronyms request created successfully'
                },
                admin: {
                    userExists: 'User already exists',
                    userUpdated: 'User updated successfully',
                    userNotSelected: 'You have not selected any user',
                    needManager: 'Manager is mandatory for the assignments',
                    needLeadGroups: 'Responsible Group is mandatory for assigning user to Tools Manager',
                    enterMandatoryFields: 'Please Mandatory Fields',
                    adminSaveSuccessful: 'Master Details saved successful',
                    adminUpdateSuccessful: 'Master Details updated successfully',
                    adminRejectSuccessful: 'Master Details Deleted successfully'
                },
                searchBoeingUsers: {
                    mandatoryFieldErrorMessage: 'Please enter at least one value',
                    bemsIdNumericErrorMessage: 'Bems Id should be numeric!'
                },
                assignRole: {
                    roleAssignActiveUserErrorMessage: 'Atleast one role should be assigned to active user',
                    userAddedToTeamSuccessMessage: 'User is successfully added to TEAM application!',
                    roleAssignSuccessMessage: 'Role Assignment is successful!',
                    cancelAddingUserToTeamTitleMessage: 'Discard Changes',
                    cancelAddingUserToTeamTextMessage: 'You will not be able to recover the changes!'
                }
            });
})();




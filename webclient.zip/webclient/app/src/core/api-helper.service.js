(function () {
    'use strict';

    angular
            .module('app.core')
            .factory('apiHelper', apiHelper);

    apiHelper.$inject = ['$location'];

    function apiHelper($location) {
        var rootUrl = $location.protocol() + '://' + $location.host() + ':' + $location.port() + '/api';
        var service = {
            getRootUrl: getRootUrl
        };

        return service; 

        function getRootUrl() {
            return rootUrl;
        }

    }
})();


(function() {
    'use strict';
    
    angular.module('app.core', [
       /*
        * Angular modules
        */ 
       'ngResource',
       'ngAnimate',
       'ngMessages',
       /*
        * Our reuseable cross app code modules        
        */
       'blocks.router'
    ]);
})();



(function () {
    angular.module('app.layout')
            .controller('SidebarController', SidebarController);

    SidebarController.$inject = ['authService', '$rootScope', 'userRole', 'searchStateService'];
    function SidebarController(authService, $rootScope, userRole, searchStateService) {
        var vm = this;
        vm.administration = {};
        vm.isNewRequest = isNewRequest;
        vm.isShowAdmin = false;
        vm.requestTypes = [
            {name: 'Access Panels', state: 'request.access-panels'},
            {name: 'Acronyms / Abbreviations', state: 'request.acronyms-abbrev'},
            {name: 'Applicabilities', state: 'request.applicabilities'},
            {name: 'Cautions / Warnings', state: 'request.cautions'},
            {name: 'Circuit Breakers', state: 'request.circuit-breakers'},
            {name: 'Consumables', state: 'request.consumables'},
            {name: 'Disassembly Code', state: 'request.disassembly-code'},
            {name: 'Hazardous Material', state: 'request.hazardous-material'},
            {name: 'InfoCode', state: 'request.infocode'},
            {name: 'SNS', state: 'request.sns'},
            {name: 'Source Data', state: 'request.source-data'},
            {name: 'Tool Requirements', state: 'request.tool-requirements'},
            {name: 'Zones', state: 'request.zones'}
        ];

        vm.administration = {name: 'Administration', state: 'administration'};

        $rootScope.$on('updateSidebar', updateSidebar);

        initialize();
        function initialize() {
            vm.isShowAdmin = false;
            var userDetails = authService.getUser();
            if (angular.isUndefined(userDetails)) {
                authService.getUserDetails().then(function (result) {
                    if (result.userRoleVO.roleId === userRole.ADMIN)
                        vm.isShowAdmin = true;
                }).catch(function (error) {

                });
            } else {
                if (userDetails.userRoleVO.roleId === userRole.ADMIN)
                    vm.isShowAdmin = true;
            }
        }

        function updateSidebar() {
            initialize();
        }
        function isNewRequest() {
            searchStateService.isNewRequest = false;
        }
    }
})();
(function () {
    'use strict';

    angular
        .module('app.layout')
        .controller('LayoutController', LayoutController);

    LayoutController.$inject = ['layoutService'];

    function LayoutController(layoutService) {
        var vm = this;
        vm.layout = layoutService;
    }
})();



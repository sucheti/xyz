(function() {
    'use strict';
    
    angular
        .module('app.layout')
        .factory('breadcrumbsService', breadcrumbsService);
    
    breadcrumbsService.$inject = ['$rootScope', '$state'];
    
    function breadcrumbsService($rootScope, $state) {        
        var breadcrumbs = computeBreadcrumbs();                
        var service = {
            getAll: getAll
        };        
        
        $rootScope.$on('$stateChangeSuccess', function() {            
            breadcrumbs = computeBreadcrumbs();
        });
        
        return service;        
        ///////////////                
        
        function getAll() {
            return breadcrumbs;
        }                
        
        function computeBreadcrumbs() {            
            var results = [];                 
            
            // get the individual child/parent state names i.e. foo.bar.baz -> [foo, bar, baz]
            var stateElements = $state.current.name.split('.');                       
            var displayNames;
            //If diplayName is there then use the display name or use state name as display name
            if ($state.current.displayName) {
                displayNames = $state.current.displayName.split('.');
            }else{
                displayNames = stateElements;
            }
            // reassemble the individual child/parent state names based on position in the breadcrumb
            var breadcrumbState = function (index) {
                return stateElements.slice(0, index + 1).join('.');
            };                        
            
            for(var i = 0; i < stateElements.length; i++) {
                 results.push({ displayName: displayNames[i], state: breadcrumbState(i), url: $state.href(breadcrumbState(i)) });
                }            
            
            return results;
        }                
    }
})();


(function() {
    'use strict';
    
    angular
            .module('app.layout')
            .controller('GsespHeaderController', GsespHeaderController);
    
    GsespHeaderController.$inject = ['breadcrumbsService', 'layoutService','$uibModal'];
    
    function GsespHeaderController(breadcrumbsService, layoutService,$uibModal) {        
        var vm = this;
        vm.layout = layoutService;
        vm.breadcrumbs = breadcrumbsService;
          vm.openLmContact = openLmContact;
        function openLmContact() {
            var uibModalInstance = {
                animation: true,
                templateUrl: 'src/lm-contacts/lm-contacts-modal.html',
                controller: 'LmContactsController',
                controllerAs: 'vm',
                size: 'lg',
                backdrop: 'static',
                keyboard: true

            };
            $uibModal.open(uibModalInstance);
        }
    }
})();



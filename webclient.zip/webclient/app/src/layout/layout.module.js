(function() {
    'use strict';
    
    angular.module('app.layout', [        
        'ui.bootstrap',
        'materialAdmin'
    ]);
})();


(function() {
    'use strict';
    
    angular
        .module('app.layout')
        .factory('layoutService', layoutService);
    
        function layoutService() {            
            var sidebarToggle = true;            
            var service = {
                sidebarToggle: sidebarToggle
            };            
            return service;            
        }
})();



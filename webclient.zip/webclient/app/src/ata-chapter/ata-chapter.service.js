(function () {
    'use strict';

    angular
            .module('gsesp.ataChapter')
            .factory('ataChapterService', ataChapterService);

    ataChapterService.$inject = ['$http', 'apiHelper'];

    function ataChapterService($http, apiHelper) {

        var service = {
            getAllATAChapterOption: getAllATAChapterOption
        };

        return service;


        function getAllATAChapterOption() {
            return $http.get('src/ata-chapter/data/ata-chapter.json')
                    .then(getAllATAChapterOptionSuccess);

            function getAllATAChapterOptionSuccess(response) {
                return response.data;
            }
        }


    }
})();



(function () {
    'use strict';

    angular.module('gsesp.ataChapter', [
        'ui.bootstrap'
    ]);
})();